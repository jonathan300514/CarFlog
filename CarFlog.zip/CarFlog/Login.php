<?php
session_start();



if(isset($_SESSION['usr_id'])!="") {
	header("Location: loggedin.php");
} //redirects to the users pages if logged in

include_once 'Incs/dbh.inc.php';

include 'Incs/HeadItems.php';
include 'Incs/Head.php';
?>







<main>
	<link href="css/LogStyle.css" type="text/css" rel="stylesheet" media="all"/>





<div class="container log">
	<h1 class="black-text TextAlign">Login</h1>
	<div class="row">
		<div class="col-md-4 col-md-offset-4 well">
			<form action="Incs/Login.inc.php" method="post" name="loginform">
				<fieldset>


					<div class="form-group">
						<label for="Username" class="black-text">Username</label>
						<input type="text" id="Username" name="Username" placeholder="Your Username" required class="form-control black-text"/>
					</div>

					<div class="form-group">
						<label for="Password" class="black-text">Password</label>
						<input type="password" id="Password" name="Password" placeholder="Your Password" required class="form-control black-text"/>
					</div>



					<div class="form-group TextAlign">
						<input type="submit" name="submit" value="submit" class="btn" />
					</div>
				</fieldset>
			</form>
			<span class="text-danger"><?php if (isset($errormsg)) { echo $errormsg; } ?></span>
		</div>
	</div>
	<div class="row" style="color: white;">
		<div class="col-md-4 col-md-offset-4 text-center black-text">
		New User? <a href="Register.php" class="black-text">Sign Up Here</a>
		</div>
		<div class="col-md-4 text-center black-text">
		Forgot my password? <a href="forgot.php" class="black-text">Reset my password</a>
		</div>
	</div>
</div>


</main>

<?php
include 'Incs/Footer.php';
 ?>
