<?php
/*Prints array for maintinance*/
//print_r($_GET);
session_start();


if(isset($_SESSION['u_id']) == null) {
	unset($_GET['Make']);
  unset($_GET['Model']);
}

if ((!isset($_SESSION['Welc'])) && (isset($_SESSION['u_id']))) {
  $_SESSION['Welc'] = "1";
  $firstWelc = 1;
} else {
  $firstWelc = 0;
}

//Your Database connection string
include 'Incs/Dbh.php';




$UserID = $_SESSION['u_id'];
// echo $UserID;


$Signup = $_GET['signup'];




/*The distance calculation script allowing The miles between GPS positions to be estimated*/
include 'Incs/Distance.calc.php';


/*Wipes the make or model to stop the previous screen*/
$WipeOut = $_GET["WipeOut"];


$QueryName = $_GET["QueryName"];
/*Start of Saved Searches section*/
if (isset($QueryName)) {


$sql = "SELECT * FROM Searches WHERE Name='$QueryName' && UserID ='$UserID'";
//echo $sql;
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
 // output data of each row
 while($row = mysqli_fetch_assoc($result)) {

   $SearchID = $row["SearchID"];
$_GET["SavedSearchOutput"] = $SearchID;
 }
}
}

/*Is used to pass the value of the Saved Search ID to the SQL to retrieve there search parameters*/
$SavedSearch = $_GET["SavedSearchOutput"];







if ($firstWelc == 1) {

  $sql = 'SELECT * FROM Searches where UserID = ' . $UserID . ' ORDER BY Used DESC LIMIT 1';

  //echo $sql;
  $result = mysqli_query($conn, $sql);

  if (mysqli_num_rows($result) > 0) {
   // output data of each row
   while($row = mysqli_fetch_assoc($result)) {

     $SrchID = $row["SearchID"];


  $SearchLoop++;
  }
  }
}



/*Adds a where to the Saved search when its required*/
if (isset($SavedSearch)) {
  $Where = ' WHERE SearchID = ' . $SavedSearch;
} elseif (isset($SrchID)) {
  $Where = ' WHERE SearchID = ' . $SrchID;
}



/*Starts the loop incrementaion*/
$SearchLoop = 0;
$SVSItemOutLoop = 0;
$SVSItemOutLoopNeg = -1;
/*SQL for the Saved search*/
$sql = "SELECT * FROM Searches $Where ";
//echo $sql;

/*Start of value setting from SQL ressuts*/
if ((isset($SavedSearch)) || (isset($SrchID))) {
  $result = mysqli_query($conn, $sql);
}


if (mysqli_num_rows($result) > 0) {
 // output data of each row
 while($row = mysqli_fetch_assoc($result)) {

  $SHID[$SearchLoop] = $row["SearchID"];
  $SHName[$SearchLoop] = $row["Name"];
  $SHQuery[$SearchLoop] = $row["Query"];
  $QueryItems = explode("¬", $SHQuery[$SearchLoop]);

while (isset($QueryItems[$SVSItemOutLoop])) {

$SVSItemOutLoop++;
$SVSItemOutLoopNeg++;

$Center = $QueryItems[$SVSItemOutLoopNeg];
$_GET[$Center] = $QueryItems[$SVSItemOutLoop];

//echo $_GET[$Center];
}


/*Will convert table contents to GET data for use with the rest of the Search System*/
$SearchLoop++;
}
}











if (isset($SavedSearch)) {

$sql = "SELECT * FROM Searches WHERE SearchID = $SavedSearch";


  $result = mysqli_query($conn, $sql);
  if (mysqli_num_rows($result) > 0) {
   // output data of each row
   while($row = mysqli_fetch_assoc($result)) {

    $Used = $row["Used"];
  $Used++;
  }
}

$sql = "UPDATE Searches SET Used = $Used WHERE SearchID = $SavedSearch";
//Updates the searhes that have been used

  $result = mysqli_query($conn, $sql);

}







$val = 0; //defined variables
$LoopSet = 0;
$LoopSet1 = 0;
$LoopSet2 = 0;

$LoopReturn = '0';
$LoopReturn1 = 0;
/*This is used for the search and is pulled from GET from the form. Duplicate this and add if staments
To add extra search terms*/


include 'Incs/DeclareGET.php';
//omitted but designed to return GET variables

$searchedTerm = $_GET["Search"];
$Manual = $_GET["Man"];
$Auto = $_GET["Auto"];
$Paint = $_GET["Paint"];
$MakeCar = $_GET["Make"];
$ModelCar = $_GET["Model"];


$CarTypeSPORT = $_GET["Sport"];
$CarTypeEST = $_GET["Estate"];
$CarTypeCON = $_GET["Con"];
$CarTypeCO = $_GET["Coupe"];
$CarTypeOTHER = $_GET["Other"];
$CarTypeHAT = $_GET["Hatchback"];
$Diesel = $_GET["Diesel"];
$Petrol = $_GET["Petrol"];
$Electric = $_GET["Elec"];
$SemiAuto = $_GET["SemiAuto"];

$LimitNum = $_GET["Limit"];
$submit = $_GET["submit"];

$DistanceSet = $_GET["Range"];
$DistanceSet = round($DistanceSet);
$DistanceSet = (int)$DistanceSet;
//Sets distance for use in calculation of distance


if ((isset($MakeCar)) && (isset($ModelCar)) && (isset($WipeOut))) {
unset($ModelCar);
unset($_GET["Model"]);
unset($WipeOut);
} else if ((isset($MakeCar)) && (isset($WipeOut))) {
unset($MakeCar);
unset($_GET["Make"]);
unset($WipeOut);
} //Unsets car details on search





$LoopsetDist = 0;
$Type = 0;
//Pulls images

$sql = 'SELECT * FROM Search
 INNER JOIN CarImg ON Search.ItemID=CarImg.ItemID
 WHERE AdminApproval = 1 && Sold = 0';



/*Encapsulated in an if as the blank string brings up a false positive onload*/



//These duplicated blocks add elements to the sql statment and allow the search to be conducted

if ($searchedTerm != null) {

   $Search = " (Search.Make LIKE '%$searchedTerm%' or Search.Model LIKE '%$searchedTerm%')";

    $sql = $sql . " && " . $Search;

}

if ($Manual != null) {

   $Search1 = " Search.Gearbox = 'Manual'";

   if ($Type == 1) {
     $sql = $sql . " or " . $Search1;
   } else {
     $sql = $sql . " && ( " . $Search1;
     $Type = 1;
   }

}

if ($Auto != null) {

   $Search2 = " Search.Gearbox = 'Automatic'";

   if ($Type == 1) {
     $sql = $sql . " or " . $Search2;
   } else {
     $sql = $sql . " && ( " . $Search2;
     $Type = 1;
   }

}



if ($Type == 1) {

    $sql = $sql . " )";
}

$Type = 0;


if ($Paint != 'Blank') {
  if ($Paint != null) {

     $Search3 = " Search.Paint = '$Paint'";

      $sql = $sql . " && " . $Search3;

  }
}

if ($MakeCar != 'Blank') {
  if ($MakeCar != null) {

     $Search4 = " Search.Make = '$MakeCar'";

      $sql = $sql . " && " . $Search4;

  }
}


if ($CarTypeCON != 'Blank') {
  if ($CarTypeCON != null) {
$Search5 = " Search.Type = 'Convertable'";

    if ($Type = 1) {
      $sql = $sql . " or " . $Search5;
    } else {
      $sql = $sql . " && ( " . $Search5;
       $Type = 1;
    }





  }
}

if ($CarTypeCO != 'Blank') {
  if ($CarTypeCO != null) {

     $Search6 = " Search.Type = 'Coupe'";

     if ($Type == 1) {
       $sql = $sql . " or " . $Search6;
     } else {
       $sql = $sql . " && ( " . $Search6;
        $Type = 1;
     }


  }
}

if ($CarTypeEST != 'Blank') {
  if ($CarTypeEST != null) {

     $Search7 = " Search.Type = 'Estate'";

     if ($Type == 1) {
       $sql = $sql . " or " . $Search7;
     } else {
       $sql = $sql . " && ( " . $Search7;
        $Type = 1;
     }


  }
}

if ($CarTypeHAT != 'Blank') {
  if ($CarTypeHAT != null) {

     $Search8 = " Search.Type = 'Hatchback'";

     if ($Type == 1) {
       $sql = $sql . " or " . $Search8;
     } else {
       $sql = $sql . " && ( " . $Search8;
        $Type = 1;
     }


  }
}

if ($CarTypeOTHER != 'Blank') {
  if ($CarTypeOTHER != null) {

     $Search9 = " Search.Type = 'Other'";

     if ($Type == 1) {
       $sql = $sql . " or " . $Search9;
     } else {
       $sql = $sql . " && ( " . $Search9;
        $Type = 1;
     }


  }
}

if ($CarTypeSPORT != 'Blank') {
  if ($CarTypeSPORT != null) {

     $Search10 = " Search.Type = 'Sports'";

     if ($Type == 1) {
       $sql = $sql . " or " . $Search10;
     } else {
       $sql = $sql . " && ( " . $Search10;
       $Type = 1;
     }


  }
}


if ($Type == 1) {

    $sql = $sql . " )";
}

$Type = 0;


if ($Petrol != null) {

   $Search11 = " Search.FuelType = 'Petrol'";

   if ($Type == 1) {
     $sql = $sql . " or " . $Search11;
   } else {
     $sql = $sql . " && ( " . $Search11;
     $Type = 1;
   }

}

if ($Diesel != null) {

   $Search12 = " Search.FuelType = 'Diesel'";

   if ($Type == 1) {
     $sql = $sql . " or " . $Search12;
   } else {
     $sql = $sql . " && ( " . $Search12;
     $Type = 1;
   }

}


if ($Electric != null) {

   $Search13 = " Search.FuelType = 'Electric'";

   if ($Type == 1) {
     $sql = $sql . " or " . $Search13;
   } else {
     $sql = $sql . " && ( " . $Search13;
     $Type = 1;
   }

}


if ($Type == 1) {

    $sql = $sql . " )";
    $Type = 0;
}

if ($SemiAuto != null) {

   $Search14 = " Search.Gearbox = 'Semi-Automatic'";

   if ($Type == 1) {
     $sql = $sql . " or " . $Search14;
   } else {
     $sql = $sql . " && ( " . $Search14;
     $Type = 1;
   }

}

if ($ModelCar != null) {

   $Search15 = " Search.Model = '$ModelCar'";

   if ($Type == 1) {
     $sql = $sql . " or " . $Search15;
   } else {
     $sql = $sql . " && ( " . $Search15;
     $Type = 1;
   }

}


if ($Type == 1) {

    $sql = $sql . " )";
}


/*$sqlEnd = '&& (ItemID, Make, Price) in
(select min(ItemID),Make, min(Price)
from Search
group by Make)';
$sql = $sql . $sqlEnd;*/


//Allows the order to be set for the search
$OrderPT = explode("*", $_GET["Order"]);

$Order = array("Search.Price", "Search.Make", "Search.Miles", "Search.Age", "Search.Model");

$Low = ' ORDER BY ' . $Order[$OrderPT[1]] . ' ASC';
$High = ' ORDER BY ' . $Order[$OrderPT[1]] . ' DESC';
$Random = ' ORDER BY RAND()';
$Rand = 0;








$Min = 1;
if ($OrderPT[0] === '0') {
  $sql = $sql . $Low;
}

if ($OrderPT[0] == 1) {
  $sql = $sql . $High;
}



//Brands of the car

$MakesArray = array();
//echo $sql;



$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
 // output data of each row
 while($row = mysqli_fetch_assoc($result)) {

if ((isset($MakeCar)) && (isset($ModelCar))) {
$DupTest = 1;
$ModSet = 1;
//Sets the cars and there constraints

} else if (isset($MakeCar)) {
$DupTest = 1;
if (in_array($row["Model"], $MakesArray)) {
   $Blank = " ";
   $DupTest = 0;
   $LoopSet = $LoopSet - 1;
   $ModSet = 1;
} else {
  $DupTest = 1;
  array_push($MakesArray, $row["Model"]);
  $Blank = "   "; //Checks the array for the make/ model and amends the array
  $ModSet = 1;
}
} else {
  if (in_array($row["Make"], $MakesArray)) {
     $Blank = " ";
     $DupTest = 0;
     $LoopSet = $LoopSet - 1;
  } else {
    $DupTest = 1;
    array_push($MakesArray, $row["Make"]);
    $Blank = "   ";
  }
}






   $LongDB[$LoopSet] = $row["LocationLong"];
   $LatDB[$LoopSet] = $row["LocationLat"]; //sets the car location

      $DistCalc[$LoopSet] = distance($_GET["Lat"], $_GET["Long"], $LatDB[$LoopSet], $LongDB[$LoopSet] , "M") . " Miles<br>";
//Works out the distance from user


if (($_GET["Lat"] != null) && ($_GET["Long"] != null) && ($_GET["Range"] != null) && ($_GET["Range"] != '0')) {

  if (($DistCalc[$LoopSet] < $DistanceSet) && ($DupTest == 1)) {
//cars set when distanc is within paramaters
   $Make[$LoopSet]    = $row["Make"];
   $Model[$LoopSet]   = $row["Model"];
   $Gearbox[$LoopSet] = $row["Gearbox"];
   $PaintDb[$LoopSet] = $row["Paint"];
    $ID[$LoopSet] = $row["ItemID"];
    $FuelType[$LoopSet] = $row["FuelType"];
    $Age[$LoopSet] = $row["Age"];
    $Type[$LoopSet] = $row["Type"];
    $Price[$LoopSet] = $row["Price"];
    $Disc[$LoopSet] = $row["Disc"];
    $Doors[$LoopSet] = $row["Doors"];

   $Location[$LoopSet] = $row["Location"];
   $Miles[$LoopSet] = $row["Miles"];
   $CarImg[$LoopSet] = $row["ImgPath"];
 } else {
   echo ' ';
 }

} else if ($DupTest == 1) {
	//If distance is not set
  $Make[$LoopSet]    = $row["Make"];
  $Model[$LoopSet]   = $row["Model"];
  $Gearbox[$LoopSet] = $row["Gearbox"];
  $PaintDb[$LoopSet] = $row["Paint"];
   $ID[$LoopSet] = $row["ItemID"];
   $FuelType[$LoopSet] = $row["FuelType"];
   $Age[$LoopSet] = $row["Age"];
   $Type[$LoopSet] = $row["Type"];
   $Price[$LoopSet] = $row["Price"];
   $Disc[$LoopSet] = $row["Disc"];
   $Doors[$LoopSet] = $row["Doors"];
   $Location[$LoopSet] = $row["Location"];
   $CarImg[$LoopSet] = $row["ImgPath"];
}

   $LoopSet++;
 }
} else {
 echo " ";

}

$sql1 = "SELECT * FROM CarPaint";
//Selects paint color and hex code
$result1 = mysqli_query($conn, $sql1);
if (mysqli_num_rows($result1) > 0) {
 // output data of each row
 while($row = mysqli_fetch_assoc($result1)) {

   $PName[$LoopSet1]    = $row["Name"];
   $Code[$LoopSet1]   = $row["Code"];

   $LoopSet1++;
 }
} else {
 echo " ";

}

$sqlBrand = "SELECT DISTINCT Make FROM Search";
//Selects car makes dependingon the array and set brands
$resultBrand = mysqli_query($conn, $sqlBrand);
if (mysqli_num_rows($resultBrand) > 0) {
 // output data of each row
 while($row = mysqli_fetch_assoc($resultBrand)) {

  $SELMake[$LoopSet2] = $row["Make"];

   $LoopSet2++;
 }
} else {
 echo " ";

}


mysqli_close($conn);


include 'Incs/HeadItems.php';
include 'Incs/Head.php';

?>
<main>

  <div class="section" id="index-banner">
    <div class="container container-margins">





      <!-- Modal Structure -->
  <div id="Welcome" class="modal">
    <div class="modal-content">
      <h3 class="center"><?php  echo "Welcome Back " . $_SESSION['u_first']; ?></h3>
    </div>
  </div>

<?php
if ($firstWelc == 1) {
  echo  '<script>';
//Runs welcome message on first view and closes after 3 seconds
    echo "jQuery(document).ready(function(){


       jQuery('#Welcome').modal();
       jQuery(document).ready(function(){
           jQuery('#Welcome').modal('open');
       });

       function show_popup(){
          $('#Welcome').slideUp();

       };

       function close_popup(){
          jQuery('#Welcome').modal('close');

       };
       window.setTimeout( show_popup, 3000 ); // 3 seconds
       window.setTimeout( close_popup, 3300 ); // 3.3 seconds
  });







  ";





  echo  '</script>';



}




?>



<?php
//Starts the form containing the car and its details
$FormSaveStart = '<form action="index.php"  id="SaveSearch">';
$FormSaveEnd = ' ';
//Creating the form
$FormSave = $FormSaveStart . $Input . $FormSaveEnd;
?>
      <!-- Save Query Modal Structure -->
        <div id="Save" class="modal">
          <div class="modal-content">
            <h4>Do you wish to save this search?</h4>

<form action="Incs/CreateSearch.php"  id="SaveSearch" method="GET">
  Name of search: <input type="text" name="SName"><br>
  <input id="SQL" name="SQL" type="hidden" value="<?php

  $LoopGET = 0;
//The array of searchable items
  $CurrentItem = array("Search", "Man", "Auto", "Paint", "Make",  "Model", "Sport", "Estate", "Con", "Coupe", "Other",
  "Hatchback", "Diesel", "Petrol", "Limit", "Range", "Lat", "Long", "SemiAuto", "Order");

  $SVSInput = ' ';


  while (isset($CurrentItem[$LoopGET])) {

if ($LoopGET == 0) {
  $FirstRun = " ";
}else {
  $FirstRun = "¬"; //this checks the first run and echos accordingly
}
  $TempVal = $CurrentItem[$LoopGET];
    if ($_GET[$TempVal] != NULL) {
      $Blank =  $_GET[$TempVal];
       $SVSInput = $SVSInput . $FirstRun . $CurrentItem[$LoopGET] . "¬" . $Blank;
    }

  $LoopGET++;
  }

   echo $SVSInput; ?>">
<?php
echo $Input;
?>
</form>

          </div>
          <div class="modal-footer">
             <a  class="modal-close waves-effect waves-green btn-flat" href="#" onclick="document.getElementById('SaveSearch').submit()">Save Search</a>

          </div>
        </div>

      <?php
if ($submit == 'Search') {
echo  '<script>';
//This opens the modal for the save on first run of the search
  echo "jQuery(document).ready(function(){
     jQuery('#Save').modal();
     jQuery(document).ready(function(){
         jQuery('#Save').modal('open');
     });
});";

echo  '</script>';
}






      include 'Incs/Modal.php';


echo '<div class="row">';


$WhileSetVal = 0;
$WhileSetValOR = 1;
      while ((isset($Make[$WhileSetVal])) || (isset($Make[$WhileSetValOR]))){
if (isset($Make[$WhileSetVal])) {
        echo  ' ';
//Echos cars that are valid related to your search
if (isset($MakeCar)) {
$Addition =  '<input type="hidden" id="Make"
   name="Model" value="'.$Model[$WhileSetVal].'">';
}
//creates the car cards
$FormTOP = '<form action="index.php" method="GET">
<input type="hidden" id="Make'.$WhileSetVal.'"
 name="Make" value="'.$Make[$WhileSetVal].'">'
. $Addition;




$LoopGET = 0;
//outputs the form variables from the array
$CurrentItem = array("Search", "Man", "Auto", "Paint", "Make",  "Model", "Sport", "Estate", "Con", "Coupe", "Other",
"Hatchback", "Diesel", "Petrol", "Limit", "Range", "Lat", "Long", "SemiAuto", "Order");

$Input = ' ';


while (isset($CurrentItem[$LoopGET])) {

$TempVal = $CurrentItem[$LoopGET];
  if ($_GET[$TempVal] != NULL) {
    $Blank = '<input type="hidden"
     name="'.$CurrentItem[$LoopGET].'" value="'. $_GET[$TempVal] . '">';
     $Input = $Input . $Blank;
  }

$LoopGET++;
}


$FormPre = $FormTOP . $Input;
//creates the form

if ((isset($MakeCar)) && (isset($ModelCar))) {
/*Go to car page link and then stop form functioning*/
$FormPre = '<a href="https://www.jd-sh.co.uk/CarFlog/car.php?CarID=' . $ID[$WhileSetVal] .'" class="button">';
$Form = ' ';
$EndVal = '</a>';
} else {
  $EndVal = '
 </form>';
}

if ($ModSet == 1) {
  $EchoCar = $Model[$WhileSetVal];
} else {
  $EchoCar = $Make[$WhileSetVal]; //ordeers the cars
}

if (($_GET["Lat"] != null) && ($_GET["Long"] != null)) {
  $CarDistance = 'You are ' . floor($DistCalc[$WhileSetVal]) . ' miles from this vehicle.';
} //rechecks the reselected cars for distance

if ((isset($MakeCar)) && (isset($ModelCar))) {
$CarOutput =
  '<div class="card-content">
    <p> £' . $Price[$WhileSetVal] . ' <br>'. $CarDistance .' </p>
  </div>';   //adds content to cards created above

$Centerval = '<img alt="CarImg" width="250" height="250" src="'. $CarImg[$WhileSetVal] .'">';

} else {
	$Centerval = '<input type="image" name="submit" '. $UserDis.' src="'. $CarImg[$WhileSetVal] .'" alt="Submit" class="InputImg" />';
}


if (!isset($UserID)) {
  $UserDis = 'disabled';
} //disables details that should be via the DB




$Card = $FormPre .
'<div class="col s12 m6 l4">
    <div class="card hoverable">
      <div class="card-image">

'.$Centerval.'

        <span class="card-title">' . $EchoCar . '</span>
      </div>
      '. $CarOutput .'
    </div>
  </div>
';
echo $Card . $EndVal;

//Echos the card that has been creatred

//. $Gearbox[$WhileSetVal] . $PName[$PaintDb[$WhileSetVal]] . $Miles[$WhileSetVal] . $Location[$WhileSetVal] . $Price[$WhileSetVal] .



            }
        $WhileSetVal++;
        $WhileSetValOR++;
      }  //used if nothing is found within the search criteria  
      if ($WhileSetVal == 0) {
        echo 'There were no ressults for this search';
      }

?>

</div>


</div>
  </div>


</main>


<?php
include 'Incs/Footer.php';
 ?>
