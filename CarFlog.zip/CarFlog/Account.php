<?php

//print_r($_POST);
//Your Database connection string
include 'Incs/Dbh.php';
session_start();
$UserID = $_SESSION['u_id'];

if (!isset($UserID)) {
  	header("Location: https://www.jd-sh.co.uk/CarFlog/index.php");
}


$sql = "SELECT * FROM users where id = '$UserID'";
//echo $sql;
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
 // output data of each row
 while($row = mysqli_fetch_assoc($result)) {

$UserName = $row["Username"];
$FirstName = $row["First"];
$LastName = $row["Last"];
$Email = $row["email"];
$DOB = $row["DOB"];
$Phone = $row["Phone"];
$Address = $row["Address"];
 }
}


$LoopSet = 0;

    $sql1 = "SELECT * FROM Search inner join CarImg on CarImg.ItemID = Search.ItemID where OwnerID = '$UserID' && Sold = '0'";

    $result1 = mysqli_query($conn, $sql1);
    if (mysqli_num_rows($result1) > 0) {
     // output data of each row
     $Not1 = 1;
     while($row = mysqli_fetch_assoc($result1)) {
       $ItemID[$LoopSet]    = $row["ItemID"];
       $Make[$LoopSet]    = $row["Make"];
       $Model[$LoopSet]   = $row["Model"];
       $Gearbox[$LoopSet] = $row["Gearbox"];
       $PaintDb[$LoopSet] = $row["Paint"];
        $ID[$LoopSet] = $row["ItemID"];
        $FuelType[$LoopSet] = $row["FuelType"];
        $Age[$LoopSet] = $row["Age"];
        $Type[$LoopSet] = $row["Type"];
        $Price[$LoopSet] = $row["Price"];
        $Disc[$LoopSet] = $row["Disc"];
        $Doors[$LoopSet] = $row["Doors"];

       $Location[$LoopSet] = $row["Location"];
       $Miles[$LoopSet] = $row["Miles"];
       $ImgPath[$LoopSet] = $row["ImgPath"];

       $LoopSet++;
     }
    } else {
     echo " ";
$Not1 = 0;
    }



    $LoopSet1 = 0;

        $sql2 = "SELECT * FROM Search inner join CarImg on CarImg.ItemID = Search.ItemID where OwnerID = '$UserID' && Sold = '1'";

        $result2 = mysqli_query($conn, $sql2);
        if (mysqli_num_rows($result2) > 0) {
         // output data of each row
         $Not = 1;
         while($row = mysqli_fetch_assoc($result2)) {
           $ItemID1[$LoopSet1]    = $row["ItemID"];
           $Make1[$LoopSet1]    = $row["Make"];
           $Model1[$LoopSet1]   = $row["Model"];
           $Gearbox1[$LoopSet1] = $row["Gearbox"];
           $PaintDb1[$LoopSet1] = $row["Paint"];
            $ID1[$LoopSet1] = $row["ItemID"];
            $FuelType1[$LoopSet1] = $row["FuelType"];
            $Age1[$LoopSet1] = $row["Age"];
            $Type1[$LoopSet1] = $row["Type"];
            $Price1[$LoopSet1] = $row["Price"];
            $Disc1[$LoopSet1] = $row["Disc"];
            $Doors1[$LoopSet1] = $row["Doors"];

           $Location1[$LoopSet1] = $row["Location"];
           $Miles1[$LoopSet1] = $row["Miles"];
           $ImgPath1[$LoopSet1] = $row["ImgPath"];

           $LoopSet1++;
         }
        } else {
         echo " ";
$Not = 0;
        }




mysqli_close($conn);
?>


<?php

include 'Incs/HeadItems.php';
include 'Incs/Head.php';

?>
<main>

  <?php

if (isset($_GET["Output"])) {
  if ($_GET["Output"] == "1") {
    echo "An email has been sent to your email address, please allow upto an hour. You will have 24hrs to respond and change your password";
  } else {
    Echo "Your email was not found. This could be due to your account not exisiting or a typo. Please try again.";
  }

}

 include 'Incs/Modal.php';
?>

  <div class="section" id="index-banner">


    <div class="row">
   <div class="col s12">
     <ul class="tabs">
       <li class="tab col s6"><a class="active" href="#test1">My Details</a></li>
       <li class="tab col s6"><a href="#test2">My Cars</a></li>
     </ul>
   </div>
   <?php
   $JUMP = 1;
   ?>
   <div id="test<?php echo $JUMP;
$JUMP++;
   ?>" class="col s12">
     <div class="container">
     <h2 class="center">My Details</h2> <br>
     <h4 class="center">Here are your current details to change these replace these values.</h4>

     <form action="Incs/ChangeDetails.php" method="post">
       Username:<br>
       <input type="text" name="uid" value="<?php echo $UserName; ?>"><br>

       First name:<br>
       <input type="text" name="first" value="<?php echo $FirstName; ?>"><br>

       Last name:<br>
       <input type="text" name="last" value="<?php echo $LastName; ?>"><br>

       Email:<br>
      <input type="text" name="email" value="<?php echo $Email; ?>"><br>

      Phone Number:<br>
     <input type="text" name="phone" value="<?php echo $Phone; ?>"><br>

     Address:<br>
     <input type="text" name="address" value="<?php echo $Address; ?>"><br>
 DOB:
 <br>

     <div class="col s4">

     <input type="text" name="DOB_date" value="<?php

     $DOB = explode("/", $DOB);
      echo $DOB[0]; ?>">
      </div>
      <div class="col s4">
      <input type="text" name="DOB_month" value="<?php
       echo $DOB[1]; ?>">
         </div>
         <div class="col s4">
       <input type="text" name="DOB_year" value="<?php
        echo $DOB[2]; ?>">
          </div>




     <br>
      <br>
      <div class="center">
        <input type="submit" name="submit" value="Change" class="btn">
      </div>
      </form>
      <div class="center">
        <a href="https://www.jd-sh.co.uk/CarFlog/email.php?Email=<?php echo $Email ?>" class="button">Change password</a>
      </div>
    </div>

   </div>

<?php

   if ($Not1 == 1) {

     echo '
   <div id="test'. $JUMP.'" class="col s12">
      <div class="container">
     <h2 class="center">My Cars - Not Sold</h2>
';
$JUMP++;
   }





    $WhileSetVal = 0;
    while (isset($ItemID[$WhileSetVal])) {

    $FormPre = '<a href="https://www.jd-sh.co.uk/CarFlog/car.php?CarID=' . $ItemID[$WhileSetVal] .'" class="button">';
    $EndVal = '</a>';
$Edit = '<a href="https://www.jd-sh.co.uk/CarFlog/Sold.php?Mod=1&CarID=' . $ItemID[$WhileSetVal] .'" class="button"><i class="material-icons">check_circle</i> Item Sold</a>';
     $Card = '<div class="col s12 m6 l4">' . $FormPre .

     '<div class="card hoverable">
           <div class="card-image">
           <img alt="CarImg" height="250" width="250" src="'. $ImgPath[$WhileSetVal] .'">

             <span class="card-title">' . $Make[$WhileSetVal] . ' ' . $Model[$WhileSetVal] . '</span>
           </div>
           </div>



     ';
     echo $Card . $EndVal . '<div class="card-content">' . $Edit . ' </div>
     </div>';

     $WhileSetVal++;
}

if ($Not1 == 1) {

echo '
   </div>
 </div>';

}




if ($Not == 1) {

  echo '<div id="test' . $JUMP . '" class="col s12">
     <div class="container">
    <h2 class="center">My Cars - Sold</h2>';
    $JUMP++;
}



  $WhileSetVal1 = 0;
  while (isset($ItemID1[$WhileSetVal1])) {



  $FormPre = '<a href="https://www.jd-sh.co.uk/CarFlog/car.php?CarID=' . $ItemID1[$WhileSetVal1] .'" class="button">';
  $EndVal = '</a>';

   $Card = $FormPre .
   '<div class="col s12 m6 l4">
   <div class="card hoverable">
         <div class="card-image">
         <img alt="CarImg" height="250" width="250" src="'. $ImgPath1[$WhileSetVal1] .'">

           <span class="card-title">' . $Make1[$WhileSetVal1] . ' ' . $Model1[$WhileSetVal1] . '</span>
         </div>
         </div>
     </div>
   ';
   echo $Card . $EndVal;

   $WhileSetVal1++;
 }

if ($Not == 1) {
echo '
 </div>
 </div>';
}
 ?>









</div>



</div>
</main>
<script>  $(document).ready(function(){
    $('.materialboxed').materialbox();
  });


  $(document).ready(function(){
      $('.tabs').tabs();
    });
</script>

<?php
include 'Incs/Footer.php';
 ?>
