-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 01, 2019 at 01:06 PM
-- Server version: 5.5.62-0+deb8u1
-- PHP Version: 5.6.39-0+deb8u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `jonathan3005_4`
--

-- --------------------------------------------------------

--
-- Table structure for table `CarImg`
--

CREATE TABLE IF NOT EXISTS `CarImg` (
`ImgID` int(11) NOT NULL,
  `ItemID` int(11) NOT NULL,
  `ImgPath` text NOT NULL,
  `ImageDisc` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `CarImg`
--

INSERT INTO `CarImg` (`ImgID`, `ItemID`, `ImgPath`, `ImageDisc`) VALUES
(1, 1, 'CarImg/Fiat-Panda.jpg', 'Fiat-Panda-Red'),
(2, 2, 'CarImg/Ferrari-Enzo.jpg', 'Ferrari-Enzo-Red'),
(3, 3, 'CarImg/Ferrari-California.jpg', 'Ferrari-California-Red'),
(4, 5, 'CarImg/Ferrari-458-Spider.jpg', 'Ferrari-458-Spider-Red'),
(6, 6, 'CarImg/Jaguar-D-Type.jpg', 'Jaguar-D-Type-Red'),
(7, 10, 'CarImg/2010_Fiat_Panda_pink.jpg', 'Fiat-Panda-Pink'),
(8, 8, 'CarImg/Jaguar-C-Type.jpg', 'Jaguar-C-Type-Red'),
(9, 4, 'CarImg/Jaguar-D-Type.jpg', 'Jaguar-D-Type-Red'),
(10, 11, 'CarImg/2008-2010_Fiat_500_Sport_hatchback_01.jpg', 'Fiat-Abarth-yellow'),
(11, 7, 'CarImg/Jaguar-E-Type.jpg', 'Jaguar-E-Type-Red'),
(12, 9, 'CarImg/etype.jpg', 'Jaguar-E-Type-Green'),
(13, 12, 'CarImg/images.jpg', 'Lamborghini-countach-Black'),
(14, 13, 'CarImg/TeslaModeltrimmed.jpg', 'TeslaModeltrimmed');

-- --------------------------------------------------------

--
-- Table structure for table `CarPaint`
--

CREATE TABLE IF NOT EXISTS `CarPaint` (
`PaintID` int(11) NOT NULL,
  `Name` text NOT NULL,
  `Code` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `CarPaint`
--

INSERT INTO `CarPaint` (`PaintID`, `Name`, `Code`) VALUES
(1, 'Red', '#e6194b'),
(2, 'Green', '#3cb44b'),
(3, 'Yellow', '#ffe119'),
(4, 'Blue', '#4363d8'),
(5, 'Orange', '#f58231'),
(6, 'Purple', '#911eb4'),
(7, 'Cyan', '#46f0f0'),
(8, 'Magenta', '#f032e6'),
(9, 'Lime', '#bcf60c'),
(10, 'Pink', '#fabebe'),
(11, 'Teal', '#008080'),
(12, 'Lavender', '#e6beff'),
(13, 'Brown', '#9a6324'),
(14, 'Beige', '#fffac8'),
(15, 'Maroon', '#800000'),
(16, 'Mint', '#aaffc3'),
(17, 'Olive', '#808000'),
(18, 'Apricot', '#ffd8b1'),
(19, 'Navy', '#000075'),
(20, 'Grey', '#808080'),
(21, 'White', '#ffffff'),
(22, 'Black', '#000000');

-- --------------------------------------------------------

--
-- Table structure for table `Search`
--

CREATE TABLE IF NOT EXISTS `Search` (
`ItemID` int(11) NOT NULL,
  `OwnerID` int(11) NOT NULL,
  `Make` text NOT NULL,
  `Model` text NOT NULL,
  `Gearbox` text NOT NULL,
  `Disc` text NOT NULL,
  `Miles` int(11) NOT NULL,
  `Age` int(11) NOT NULL,
  `FuelType` text NOT NULL,
  `Doors` int(11) NOT NULL,
  `Type` text NOT NULL,
  `Paint` int(11) NOT NULL,
  `EngineSize` varchar(11) NOT NULL,
  `Price` int(11) NOT NULL,
  `LocationLat` text NOT NULL,
  `LocationLong` text NOT NULL,
  `AdminApproval` tinyint(1) NOT NULL,
  `Sold` tinyint(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Search`
--

INSERT INTO `Search` (`ItemID`, `OwnerID`, `Make`, `Model`, `Gearbox`, `Disc`, `Miles`, `Age`, `FuelType`, `Doors`, `Type`, `Paint`, `EngineSize`, `Price`, `LocationLat`, `LocationLong`, `AdminApproval`, `Sold`) VALUES
(1, 90, 'Fiat', 'Panda', 'Automatic', 'A starter car with great insurance and good mileage from its 1l engine', 10000, 8, 'Diesel', 3, 'Hatchback', 1, '1.0', 1200, '-1.891904', '52.466390', 1, 1),
(2, 90, 'Ferrari', 'Enzo', 'Manual', 'The Ferrari that defined an era. Arguably one of the best and most precgious Ferrari''s ever.', 15243, 18, 'Petrol', 3, 'Other', 1, '3.4', 1100000, '-1.891904', '52.466390', 1, 1),
(3, 88, 'Ferrari', 'Califonia', 'Automatic', 'The modern benchmark for all GT cars, nippy through the corners but equally good sitting on the Promenade. ', 1456, 6, 'Petrol', 3, 'Convertable', 15, '2.4', 100000, '-1.891904', '52.466390', 1, 0),
(5, 88, 'Ferrari', '458 Spider', 'Semi-Automatic', 'The entry level car into the Supercar market', 1243, 15, 'Petrol', 3, 'Sports', 1, '2.0', 100000, '-1.891904', '52.466390', 1, 0),
(6, 88, 'Jaguar', 'D-Type', 'Manual', 'Jaguars staple le man car with the engine going onto be the highlight of the jaguar brand. The car won many other races including the Mille Miglia.', 7600, 72, 'Petrol', 3, 'Sports', 2, '3.8', 122240, '-2.316207', '54.301300', 1, 0),
(7, 88, 'Jaguar', 'E-Type', 'Manual', 'The Sportscar to end all others, a light, nimble and stylish car with plenty of power to boot.', 54300, 63, 'Petrol', 3, 'Sports', 15, '2.6', 122240, '-2.316207', '54.301300', 1, 0),
(8, 88, 'Jaguar', 'C-Type', 'Manual', 'A classic racecar built for the road, Suitable in any environment. Well maintained.', 12000, 75, 'Petrol', 3, 'Sports', 2, '3.4', 1020000, '-2.316207', '54.301300', 1, 0),
(9, 88, 'Jaguar', 'E-Type', 'Manual', 'A stylish designed sportscar with classic cues, built for the modern world.', 76500, 65, 'Petrol', 3, 'Sports', 2, '3.2', 122240, '-2.316207', '54.301300', 1, 0),
(10, 88, 'Fiat', 'Panda', 'Manual', 'A small first car', 10000, 8, 'Diesel', 3, 'Hatchback', 12, '1.2', 1800, '-1.891904', '52.466390', 1, 0),
(11, 88, 'Fiat', 'Abarth', 'Automatic', 'A small first car, Ideal for someone looking for a large personality in such a small car.', 100000, 8, 'Diesel', 3, 'Hatchback', 14, '1.4', 3600, '-1.891904', '52.466390', 1, 0),
(12, 87, 'Lamborghini', 'countach', 'Manual', 'The Lamborghini Countach was an Italian supercar built by Lamborghini between 1974 and 1990. It was among the first sports cars to feature a forward-positioned cabin and a large, mid-mounted engine', 12891, 34, 'Petrol', 3, 'Other', 22, '3.5', 240000, '-4.891904', '55.466390', 1, 0),
(13, 90, 'Tesla', 'S', 'Automatic', 'An electric car to compete with offerings from BMW and Audi. This car is aimed at the luxury market and shows it with large helpings of quality.', 3652, 2, 'Electric', 5, 'Coupe', 22, '2.0', 56000, '-1.708032', '52.6426112', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `Searches`
--

CREATE TABLE IF NOT EXISTS `Searches` (
`SearchID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `Name` varchar(200) NOT NULL,
  `Query` varchar(350) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Used` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Searches`
--

INSERT INTO `Searches` (`SearchID`, `UserID`, `Name`, `Query`, `Used`) VALUES
(40, 1, 'Distance', ' Â¬ManÂ¬onÂ¬PaintÂ¬BlankÂ¬RangeÂ¬437Â¬OrderÂ¬0*4', 4),
(41, 1, 'NewDist', ' Â¬PaintÂ¬BlankÂ¬RangeÂ¬437Â¬SemiAutoÂ¬onÂ¬OrderÂ¬0*4', 0),
(42, 1, 'Deisel', ' Â¬ManÂ¬onÂ¬PaintÂ¬BlankÂ¬RangeÂ¬0Â¬OrderÂ¬0*4', 1),
(43, 1, 'Short Search', ' Â¬PaintÂ¬BlankÂ¬SportÂ¬onÂ¬RangeÂ¬0Â¬SemiAutoÂ¬onÂ¬OrderÂ¬0*4', 0),
(44, 1, 'First', ' Â¬ManÂ¬onÂ¬PaintÂ¬BlankÂ¬RangeÂ¬0Â¬OrderÂ¬0*4', 0),
(45, 1, 'First', ' Â¬AutoÂ¬onÂ¬PaintÂ¬BlankÂ¬SportÂ¬onÂ¬RangeÂ¬0Â¬OrderÂ¬0*4', 0),
(46, 1, 'Firstgrgrg', ' Â¬ManÂ¬onÂ¬PaintÂ¬BlankÂ¬CoupeÂ¬onÂ¬RangeÂ¬0Â¬OrderÂ¬0*4', 0),
(47, 1, 'Sport', ' Â¬PaintÂ¬BlankÂ¬SportÂ¬onÂ¬RangeÂ¬0Â¬OrderÂ¬0*4', 0),
(48, 1, 'Sporty', ' Â¬PaintÂ¬BlankÂ¬SportÂ¬onÂ¬RangeÂ¬0Â¬OrderÂ¬0*4', 0),
(49, 1, 'Distance', ' Â¬PaintÂ¬BlankÂ¬SportÂ¬onÂ¬CoupeÂ¬onÂ¬RangeÂ¬0Â¬OrderÂ¬0*4', 0),
(50, 1, 'test', ' Â¬PaintÂ¬BlankÂ¬CoupeÂ¬onÂ¬RangeÂ¬0Â¬OrderÂ¬0*4', 0),
(51, 88, 'Man', ' Â¬ManÂ¬onÂ¬PaintÂ¬BlankÂ¬RangeÂ¬0Â¬OrderÂ¬0*4', 4),
(71, 91, 'Short Search', ' Â¬PaintÂ¬BlankÂ¬RangeÂ¬179Â¬LatÂ¬-1.7088512000000002Â¬LongÂ¬52.6426112Â¬OrderÂ¬0*4', 2),
(72, 92, 'no', ' Â¬PaintÂ¬0Â¬RangeÂ¬874Â¬OrderÂ¬0*4', 1),
(73, 90, 'Jons', ' Â¬PaintÂ¬BlankÂ¬RangeÂ¬874Â¬LatÂ¬-1.8299405Â¬LongÂ¬52.6795295Â¬OrderÂ¬0*4', 6);

-- --------------------------------------------------------

--
-- Table structure for table `SRecover`
--

CREATE TABLE IF NOT EXISTS `SRecover` (
`PassResetID` int(11) NOT NULL,
  `RequestTime` int(11) NOT NULL,
  `SecretCode` text NOT NULL,
  `Email` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `SRecover`
--

INSERT INTO `SRecover` (`PassResetID`, `RequestTime`, `SecretCode`, `Email`) VALUES
(14, 1546854750, 'R2BJA5dPr4Gj', 'jonathandartnell3005@gmail.com'),
(15, 1551097211, 'E90cLPnUXd4D', 'staceylouisehoare@yahoo.co.uk');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` int(8) NOT NULL,
  `First` text NOT NULL,
  `Last` text NOT NULL,
  `Username` varchar(30) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` text NOT NULL,
  `DOB` varchar(15) NOT NULL,
  `Phone` int(12) NOT NULL,
  `Address` varchar(255) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=97 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `First`, `Last`, `Username`, `email`, `password`, `DOB`, `Phone`, `Address`) VALUES
(93, 'callum', 'jackson', 'callum', 'crj12345678@gmail.com', '$2y$10$7BqTYaBJZlc4qK4ZgH7BJuxF8vwQd1JyFZ8nvpeAE0yWtXFz7BDKq', '0', 0, ''),
(89, 'Brad', 'Jenks', 'Brad123', 'Brad@Brad.mail.com', '$2y$10$eKZfaFFi2MLvmOaQoJTnteWB/.bHakFwWrU5ekRWAwJ0l7ted4J1y', '0', 0, ''),
(90, 'Stacey', 'Hoare', 'Blazin_2180', 'staceylouisehoare@yahoo.co.uk', '$2y$10$TgM5Vhf9S/n5t3IdOfszNeGS0X3OOrw0xzMikjKsHtjbb2VhJtyC.', '30/05/1998', 182754632, '73 eliz drive'),
(88, 'caroline', 'elson', 'Bart@Gmail.com', 'jonathandartnell3005@gmail.com', '$2y$10$KP8LW/U8aF/PQGz.kiDMbOxgisNi3sJD6eZDjMl27usmwhDxfx5Vy', '0', 0, ''),
(92, 'high', 'hig', 'hig', 'hig@hi.com', '$2y$10$JiguEsG9CpyVpL/2ms6Dg5ewukmG4ULA5dNtgZX.l9ClRVpFTL.gtu', '0', 0, ''),
(96, 'Junk', 'Man', 'JunkMan', 'JunkMan@gmail.com', '$2y$10$WIb6FOPdRoPd6kw1OuFGQudCWKuuLzcBjDfD2kjYGZz9stgJuxXTy', '30/05/1998', 182754632, '73 eliz ad drive');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `CarImg`
--
ALTER TABLE `CarImg`
 ADD PRIMARY KEY (`ImgID`);

--
-- Indexes for table `CarPaint`
--
ALTER TABLE `CarPaint`
 ADD PRIMARY KEY (`PaintID`);

--
-- Indexes for table `Search`
--
ALTER TABLE `Search`
 ADD UNIQUE KEY `ItemID` (`ItemID`);

--
-- Indexes for table `Searches`
--
ALTER TABLE `Searches`
 ADD UNIQUE KEY `ItemID` (`SearchID`);

--
-- Indexes for table `SRecover`
--
ALTER TABLE `SRecover`
 ADD PRIMARY KEY (`PassResetID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `CarImg`
--
ALTER TABLE `CarImg`
MODIFY `ImgID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `CarPaint`
--
ALTER TABLE `CarPaint`
MODIFY `PaintID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `Search`
--
ALTER TABLE `Search`
MODIFY `ItemID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `Searches`
--
ALTER TABLE `Searches`
MODIFY `SearchID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=74;
--
-- AUTO_INCREMENT for table `SRecover`
--
ALTER TABLE `SRecover`
MODIFY `PassResetID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(8) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=97;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
