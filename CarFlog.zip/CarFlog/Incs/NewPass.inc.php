<?php
include 'Dbh.php';

$adr = $_GET['Adr'];
$Cde = $_GET['UserCode'];

 $fullLink = 'https://www.jd-sh.co.uk/CarFlog/reset.php?UserCode='.$Cde.'&Adr='.$adr;

$URL = $fullLink;

if ((!isset($_POST['Pass'])) && (!isset($_POST['Passconnfirm']))){
  header('Location: '.$URL);
}


$Pass = $_POST['Pass'];

$URLTwo = 'https://www.jd-sh.co.uk/CarFlog/Login.php';

if ($_POST['Pass'] === $_POST['Passconnfirm']) {
  $NewPass = password_hash("$Pass", PASSWORD_DEFAULT);
  $Email = $_POST['Email'];
} else {
 header('Location: '.$URL);
  exit;
}



$sql1 = "UPDATE users SET password = '$NewPass' WHERE email = '$Email'";


$result1 = mysqli_query($conn, $sql1);


mysqli_close($conn);

//echo 'How';
//echo $_POST['Pass'];
//echo $_POST['Passconnfirm'];
header('Location: '.$URLTwo);

?>
