<?php

include 'Dbh.php';
$QueryName = $_GET["Qury"];


session_start();

$UserID = $_SESSION['u_id'];

$sql = "SELECT * FROM Searches WHERE Name='$QueryName' & UserID ='$UserID'";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
 // output data of each row
 while($row = mysqli_fetch_assoc($result)) {

   $SearchID = $row["SearchID"];

 }
}

header('Location: https://www.jd-sh.co.uk/CarFlog/Incs/Redirect.php?SavedSearchOutput='. $SearchID);
?>
