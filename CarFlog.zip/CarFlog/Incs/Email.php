<?php

include 'Dbh.php';



 session_start();
$UserID = $_SESSION['u_id'];


// Multiple recipients
$from = $_POST["Email"];
$Name = $_POST["Name"];
$URL = $_POST["URL"] . '&Mes=Sent';
$Content = $_POST["Content"];
//$to = 'jonathandartnell3005@gmail.com';
$CarID = $_POST["CarID"];


$sql = "SELECT * FROM Search WHERE ItemID = $CarID";


  $result = mysqli_query($conn, $sql);
  if (mysqli_num_rows($result) > 0) {
   // output data of each row
   while($row = mysqli_fetch_assoc($result)) {

    $OwnerID = $row["OwnerID"];
  }
}

$sql = "SELECT * FROM users where id = $OwnerID";


  $result = mysqli_query($conn, $sql);
  if (mysqli_num_rows($result) > 0) {
   // output data of each row
   while($row = mysqli_fetch_assoc($result)) {

    $to = $row["email"];
  }
}


// Subject
$subject = 'A message from ' . $Name . ' Via CarFlog Regarding your Car';

// Message
$message = '<html>
<head>


</head>
<body>
<p>Name: '. $Name .'</p>
<p>Email: '. $from .'</p>
  <p>Message: '. $Content .'</p>


</body>
</html>';

// To send HTML mail, the Content-type header must be set
$headers[] = 'MIME-Version: 1.0';
$headers[] = 'Content-type: text/html; charset=iso-8859-1';

// Additional headers
$headers[] = 'From: CarFlog <CarFlog@mail.com>';


// Mail it
mail($to, $subject, $message, implode("\r\n", $headers));


header('Location: '.$URL);



?>
