<!-- Modal Structure -->
<div id="modal1" class="modal">
  <div class="modal-content">
    <h4 class="center">Search</h4>

    <form action="index.php" method="GET">
      <div class="row">
        <div class="col s12 m6 l5">
          <label>Make/Model</label>
          <input type="text" name="Search" value="<?php if (isset($searchedTerm)) {
            echo $searchedTerm;
          }?>">
        </div>

        <div class="col s12 m6 l2 center">
          <label>Use GPS</label><br><br>
          <button type="button" onclick="getLocation()"><i class="material-icons">gps_fixed</i></button>
        </div>

        <div class="col s12 m6 l5">
          <label>Distance (miles)</label>
          <p class="range-field">
            <input type="range" id="Range1" name="Range" min="0" max="874" value="<?php if (empty($DistanceSet)) {
              echo "874";
            } else {
              echo $DistanceSet;
            } ?>"/>
          </p>
        </div>
      </div><!-- row end -->

      <br>

      <div class="row">
        <div class="col s12 m6 l2">
          <div class="center">
            <label>Car Type</label>
          </div>

           <p>
             <label>
               <input type="checkbox" name="Sport" <?php if (isset($_GET["Sport"])) {
                 echo 'checked';
               }?>/>
               <span>Sport</span>
             </label>
           </p>

           <p>
             <label>
               <input type="checkbox" name="Estate" <?php if (isset($_GET["Estate"])) {
                 echo 'checked';
               }?>/>
               <span>Estate</span>
             </label>
           </p>

           <p>
             <label>
               <input type="checkbox" name="Con" <?php if (isset($_GET["Con"])) {
                 echo 'checked';
               }?>/>
               <span>Convertable</span>
             </label>
           </p>
         </div>

     <div class="col s12 m6 l2">
       <br>
       <p>
         <label>
           <input type="checkbox" name="Coupe" <?php if (isset($_GET["Coupe"])) {
          echo 'checked';
           }?>/>
           <span>Coupe</span>
         </label>
       </p>

       <p>
         <label>
           <input type="checkbox" name="Hatchback" <?php if (isset($_GET["Hatchback"])) {
          echo 'checked';
           }?>/>
           <span>Hatchback</span>
         </label>
       </p>

       <p>
         <label>
           <input type="checkbox" name="Other" <?php if (isset($_GET["Other"])) {
          echo 'checked';
           }?>/>
           <span>Other</span>
         </label>
       </p>
     </div><!-- col close -->

     <div class="col s12 m6 l4" style="border-left: 1px solid #000; border-right: 1px solid #000;">

       <div class="center">
         <label>Transmission</label>
       </div>

        <p>
         <label>
           <input type="checkbox" name="Man" <?php if (isset($_GET["Man"])) {
             echo 'checked';
           }?>/>
           <span>Manual Gearbox</span>
         </label>
       </p>

       <p>
         <label>
           <input type="checkbox" name="Auto" <?php if (isset($_GET["Auto"])) {
          echo 'checked';
           }?>/>
           <span>Automatic Gearbox</span>
         </label>
       </p>

       <p>
         <label>
           <input type="checkbox" name="SemiAuto" <?php if (isset($_GET["SemiAuto"])) {
          echo 'checked';
           }?>/>
           <span>Semi-Automatic Gearbox</span>
         </label>
       </p>

     </div><!-- col close -->

     <div class="col s12 m6 l4">

       <div class="center">
         <label>Engine Type</label>
       </div>

       <p>
         <label>
           <input type="checkbox" name="Petrol" <?php if (isset($_GET["Petrol"])) {
          echo 'checked';
           }?>/>
           <span>Petrol</span>
         </label>
       </p>

       <p>
         <label>
           <input type="checkbox" name="Diesel" <?php if (isset($_GET["Diesel"])) {
          echo 'checked';
           }?>/>
           <span>Diesel</span>
         </label>
       </p>

        <p>
          <label>
            <input type="checkbox" name="Elec" <?php if (isset($_GET["Elec"])) {
           echo 'checked';
            }?>/>
            <span>Electric</span>
          </label>
        </p>

     </div><!-- col close -->
   </div><!-- row close -->


   <div class="row">
   <!-- color option start -->
   <div class="input-field col s12 m6 l6">
     <select name="Paint" class="PaintTest" style='overflow:scroll'>
       <option value="Blank" class="PaintTest">Choose an option</option>
          <?php
            while(isset($PName[$LoopReturn])) {
              if ($_GET["Paint"] == $LoopReturn) {
                $ColSelect = 'selected';
              } else {
                $ColSelect = ' ';
              }
                $Option = '<option value="' . $LoopReturn . '"' . $ColSelect . ' class="PaintTest">' . $PName[$LoopReturn] . '</option>';
                echo $Option;
                $LoopReturn++;
              }
            ?>
      </select>
      <label>Choose a color</label>
    </div>
    <!-- color option end -->

    <!-- sort start -->
    <div class="input-field col s12 m6 l6">
      <select name="Order" style='overflow:scroll'>
        <option value="0*4">Models A-Z</option>
        <?php
          $LoopReturn2 = 0;
          $OrderFilters = array("0*0", "1*0", "0*1", "1*1", "0*2", "1*2", "0*3", "1*3");
          $OrderTitles = array("Price low to high", "Price high to low", "Makes: A-Z",
          "Makes: Z-A", "Miles low to high", "Miles high to low", "Age low to high", "Age high to low");

          while(isset($OrderFilters[$LoopReturn2])) {
            if ($_GET["Order"] == $OrderFilters[$LoopReturn2]) {

            $MakeSelect = 'selected';
            } else {
              $MakeSelect = ' ';
            }
            $Option = '<option value="' . $OrderFilters[$LoopReturn2] . '"' . $MakeSelect . '>' . $OrderTitles[$LoopReturn2] . '</option>';
            echo $Option;

            $LoopReturn2++;
            }
          ?>
        </select>
        <label>Order cars by</label>
      </div>
      <!-- sort end -->

        <input type="hidden" id="Long" name="Long" value="<?php echo  $_GET["Long"]; ?>">
        <input type="hidden" id="Lat" name="Lat"   value="<?php echo  $_GET["Lat"];  ?>">
        <input class="btn" type="submit" name="submit" value="Search" style="float: right;">
      </div>
    </form>
  </div><!-- modal content end -->
</div><!-- modal end -->
