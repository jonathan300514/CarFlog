<?php


include 'Dbh.php';

session_start();
$UserID = $_SESSION['u_id'];


if (isset($_POST['Del'])) {
$DELETE = $_POST['Del'];

  $sql = "DELETE FROM Searches WHERE SearchID = $DELETE";

  /*Delete query*/

    $result = mysqli_query($conn, $sql);
mysqli_close($conn);
header('Location: https://www.jd-sh.co.uk/CarFlog/SrcMan.php');


}
?>
