<?php

//print_r($_GET);
//Your Database connection string
include 'Dbh.php';



session_start();
$UserID = $_SESSION['u_id'];
//echo $UserID;


/*Query saving bit*/

if ((isset($_GET["SQL"])) && (isset($_GET["SName"]))) {


$Data = $_GET["SQL"];
$QueryName = $_GET["SName"];




if ((empty($Data)) || (empty($QueryName))) {
  header("Location: ../index.php?SrcNameEmpty=1");
  exit();
} else {
      $sql = "SELECT * FROM Searches WHERE Name='$QueryName' & UserID ='$UserID'";
      $result = mysqli_query($conn, $sql);
      $resultCheck = mysqli_num_rows($result);
}
      if ($resultCheck > 0) {
        header("Location: ../Register.php?SrcNameUsed=1");
        exit();
      } else {
          $sql = "INSERT INTO Searches (SearchID, UserID, Name, Query, Used) VALUES (NULL, $UserID, '$QueryName', '$Data', '0')";

          $result = mysqli_query($conn, $sql);
      }


      }

/*Query saving bit end*/



header('Location: https://www.jd-sh.co.uk/CarFlog/index.php?QueryName='. $QueryName);

?>
