<?php

print_r($_POST);
//Your Database connection string
	include_once 'Dbh.php';
session_start();
$UserID = $_SESSION['u_id'];
$URL = 'https://www.jd-sh.co.uk/CarFlog/Account.php';








if (isset($_POST['submit'])) {



	$first = $_POST['first'];
	$last =  $_POST['last'];
	$email = $_POST['email'];
	$uid = $_POST['uid'];
	$DOB_date = $_POST['DOB_date'];
	$DOB_month = $_POST['DOB_month'];
	$DOB_year = $_POST['DOB_year'];
	$Phone = $_POST['phone'];
	$Address = $_POST['address'];


	//Error handlers
	//Check everything is filled out

	if (empty($first) || empty($last) || empty($email) || empty($uid) || empty($Phone) || empty($DOB_date) || empty($DOB_month) || empty($DOB_year) || empty($Address)) {
		header('Location: '. $URL .'?Change=empty');
		exit();
	} else {
		//Check if input characters are valid
		if (!preg_match("/^[a-zA-Z]*$/", $first) || !preg_match("/^[a-zA-Z]*$/", $last) || !preg_match("/^[0-9\ ]*$/", $Phone) || !preg_match("/^[0-9]*$/", $DOB_date) || !preg_match("/^[0-9]*$/", $DOB_month) || !preg_match("/^[0-9]*$/", $DOB_year)) {
			header('Location: '. $URL .'?Change=invalid');
			exit();
		} else {
			//Check if email is valid
			if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
				header('Location: '. $URL .'?Change=email');
				exit();

				$DOB_date_length = strlen($DOB_date);
				$DOB_month_length = strlen($DOB_month);
				$DOB_year_length = strlen($DOB_year);
			} else if ($DOB_date_length == 2 && $DOB_month_length == 2 && $DOB_year_length == 4) {
header("Location: ../Register.php?signup=Dob");
exit();
			} else {

					$DOB = $DOB_date . "/" . $DOB_month . "/" . $DOB_year;
					//update the user into the database
          $sql = "UPDATE users SET First = '$first', Last = '$last', Username = '$uid', email = '$email', DOB = '$DOB', Phone = '$Phone', Address = '$Address' WHERE id = '$UserID'";
          //echo $sql;
          mysqli_query($conn, $sql);

					header('Location: '. $URL .'?Change=success');
					exit();
				}
			}
	}

} else {
	header('Location: '. $URL);
	exit();
}






mysqli_close($conn);














header('Location: '. $URL);


?>
