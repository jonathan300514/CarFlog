<?php
$PageAddress = "https://www.jd-sh.co.uk/breakblocks/index.html";
$PageTitle = "CarFlog";
$Keywords = "Cars,Sales,Automobiles";
$PageDisc = "A platform to sell and buy used cars, With many makes and models avalible at a glance";
$FrontImgAddress = "https://www.jd-sh.co.uk/Assets/images/Logo-Share.jpg";
$TwitterTag = "@jonathan300514";
$CreateTime = "2018-12-29T00:23:00+01:00";
$EditTime = "2018-04-29T00:23:00+01:00";
$LogoImg = "https://www.jd-sh.co.uk/CarFlog/Assets/Logo.png";

/*If you want analytics setup*/
$Analytics = "1";


/*Page is to be restricted 1 = Yes / 0 = No *What rank from
If index is restricted it will show a 403 page*/
$Lockout = '1*4';

?>
