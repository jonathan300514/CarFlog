<?php

$dbServername = "mysql-55.int.mythic-beasts.com";
$dbUsername = "jonathan3005_4";
$dbPassword = "jonathan3005";
$dbName = "jonathan3005_4";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);

?>
