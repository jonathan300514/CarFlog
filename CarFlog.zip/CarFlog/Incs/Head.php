<!DOCTYPE html>
<html itemscope itemtype="<?php echo $PageAddress ?>" lang="en">

	<head>


		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

	  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	  <meta name="viewport" content="width=device-width, initial-scale=1"/>
	  <title><?php echo $PageTitle ?></title>
    <meta name="keywords" content="<?php echo $Keywords ?>">

	   <!-- Update your HtMl tag to include the itemscope and itemtype attributes. -->

	<!-- Place this data between the <head> tags of your website -->

	<meta name="description" content="<?php echo $PageDisc ?>"/>
	<!-- Schema.org markup for Google+ -->
	<meta itemprop="name" content="<?php echo $PageTitle ?>"/>
	<meta itemprop="description" content="<?php echo $PageDisc ?>"/>
	<meta itemprop="image" content="<?php echo $FrontImgAddress ?>"/>
	<!-- Twitter Card data -->
	<meta name="twitter:card" content="summary_large_image"/>
	<meta name="twitter:site" content="<?php echo $TwitterTag ?>"/>
	<meta name="twitter:title" content="<?php echo $PageTitle ?>"/>
	<meta name="twitter:description" content="<?php echo $PageDisc ?>"/>
	<meta name="twitter:creator" content="<?php echo $TwitterTag ?>"/>
	<!-- Twitter summary card with large image must be at least 280x150px -->
	<meta name="twitter:image:src" content="<?php echo $FrontImgAddress ?>"/>
	<!-- Open Graph data -->
	<meta property="og:title" content="<?php echo $PageTitle ?>"/>
	<meta property="og:type" content="website"/>
	<meta property="og:url" content="<?php echo $PageAddress ?>"/>
	<meta property="og:image" content="<?php echo $FrontImgAddress ?>"/>
	<meta property="og:description" content="<?php echo $PageDisc ?>"/>
	<meta property="og:site_name" content="<?php echo $PageTitle ?>"/>
	<meta property="article:published_time" content="<?php echo $CreateTime ?>"/>
	<meta property="article:modified_time" content="<?php echo $EditTime ?>"/>
	<meta property="article:section" content="Article Section"/>
	<meta property="article:tag" content="Article Tag"/>
	<!-- DEVICE ICONS -->
	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<link rel="icon" href="<?php echo $LogoImg ?>">
	<link rel="shortcut icon" href="<?php echo $LogoImg ?>" />
	<link rel="apple-touch-icon" href="<?php echo $LogoImg ?>"/>
	<link rel="apple-touch-icon-precomposed" href="<?php echo $LogoImg ?>"/>

	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link href="css/materialize.css" type="text/css" rel="stylesheet" media="all"/>
	<link href="css/style.css" type="text/css" rel="stylesheet" media="all"/>
	<link href="css/MyStyle.css" type="text/css" rel="stylesheet" media="all"/>
	<link href="https://fonts.googleapis.com/css?family=Acme" rel="stylesheet">
	</head>


	<body>
		<!-- Dropdown Structure -->
	<ul id="dropdown1" class="dropdown-content">
		<li><a href="SrcMan.php">Manage Searches</a></li>
		<li class="divider" tabindex="-1"></li>
<?php
include 'Incs/Dbh.php';

/*Repeat of above setup for dropdown system linked to Saved Searches*/
$SearchLoop = 0;


$sql = 'SELECT * FROM Searches where UserID = ' . $UserID . ' ORDER BY Used DESC LIMIT 5';
//echo $sql;
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
 // output data of each row
 while($row = mysqli_fetch_assoc($result)) {

   $SHID[$SearchLoop] = $row["SearchID"];
   $SHName[$SearchLoop] = $row["Name"];
   $SHQuery[$SearchLoop] = $row["Query"];

$SearchLoop++;
}
}
/*End of saved Searches section*/




$LoopHead = 0;

while (isset($SHID[$LoopHead])) {

	 echo '

<li><a href="#!" onclick="document.getElementById(\'RunSearch'.$LoopHead.'\').submit()">'. $SHName[$LoopHead] .'</a></li>
';

$FormSerh[$LoopHead] = '<form action="index.php" method="GET" id="RunSearch'.$LoopHead.'" style="height: 1%;">
<input type="hidden" id="'.$SHID[$LoopHead].'" name="SavedSearchOutput" value="'.$SHID[$LoopHead].'">
</form>';

$LoopHead++;
}



mysqli_close($conn);
?>

</ul>





	  <nav class="light-blue lighten-1 my-text">
	    <div class="nav-wrapper nav-padding"><a id="logo-container" href="https://www.jd-sh.co.uk/CarFlog/index.php" class="brand-logo"><img src="<?php echo $LogoImg ?>" alt="Logo" height="60" width="60"></a>
	      <ul class="right hide-on-med-and-down">
					<!-- Modal Trigger -->

					<?php
					 if (isset($UserID)) {
						$SearchModal = '<li><a class="modal-trigger" href="#modal1">Search</a></li>
						<li><a class="dropdown-trigger" href="#!" data-target="dropdown1">Saved Searches<i class="material-icons right">arrow_drop_down</i></a></li>

						<li><a href="Post.php">Post a car</a></li>
						<li><a href="Account.php">Your account</a></li>

						';

					}

					echo $SearchModal;
					?>




					<?php
					 if (isset($UserID)) {
						$LogStat1 = "Incs/Logout.inc.php";
						$LogStat2 = "Logout";
					} else {
						$LogStat1 = "Login.php";
						$LogStat2 = "Login/Register";
					}
					?>
	        <li><a href="<?php echo $LogStat1 ?>"><?php echo $LogStat2 ?></a></li>


	      </ul>

	      <ul id="nav-mobile" class="sidenav">
	        <li><a class="waves-effect waves-light btn modal-trigger" href="#modal1">Search</a></li>
					<li><a href="SrcMan.php">Saved Searches</a></li>
	        <li><a href="Post.php">Post a car</a></li>
	        <li><a href="Account.php">Your account</a></li>
	        <li><a href="<?php echo $LogStat1 ?>"><?php echo $LogStat2 ?></a></li>
	      </ul>
	      <a href="#" data-target="nav-mobile" class="sidenav-trigger"><i class="material-icons">menu</i></a>
	    </div>
	  </nav>
<?php


$FormTOP = '<form action="index.php" method="GET">
<input type="hidden" id="WipeOut" name="WipeOut" value="Wipe">';



 $FormBTM = '<input type="submit" class="btn" value="<">
</form>';

$LoopGET = 0;

$CurrentItem = array("Search", "Man", "Auto", "Paint", "Make", "Model", "Sport", "Estate", "Con", "Coupe", "Other",
"Hatchback", "Diesel", "Petrol", "Limit", "Range", "Lat", "Long", "SemiAuto", "Order");

$Input = ' ';


while (isset($CurrentItem[$LoopGET])) {

$TempVal = $CurrentItem[$LoopGET];
  if ($_GET[$TempVal] != NULL) {
    $Blank = '<input type="hidden" 
     name="'.$CurrentItem[$LoopGET].'" value="'. $_GET[$TempVal] . '">';
     $Input = $Input . $Blank;
  }

$LoopGET++;
}

$Form = $FormTOP . $Input . $FormBTM;


if (isset($MakeCar)) {
		echo '<div class="button-padding nav-wrapper">
      <div class="col s12">
         ' . $Form . '
      </div>
    </div>';

	}
$SrchOutput = 0;
while (isset($FormSerh[$SrchOutput])) {

echo $FormSerh[$SrchOutput];

$SrchOutput++;
}

		?>
