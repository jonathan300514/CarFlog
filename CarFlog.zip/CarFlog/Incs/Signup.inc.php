<?php

if (isset($_POST['submit'])) {

	include_once 'Dbh.php';

	$first = $_POST['First'];
	$last =  $_POST['Last'];
	$email = $_POST['Email'];
	$uid = $_POST['Username'];
	$Phone = $_POST['Phone_Number'];
	$DOB_date = $_POST['DOB_date'];
	$DOB_month = $_POST['DOB_month'];
	$DOB_year = $_POST['DOB_year'];
	$Address = $_POST['Address'];

	$pwd = $_POST['Password'];
	$Cpwd = $_POST['CPassword'];






	//Error handlers
	//Check everything is filled out

	if (empty($first) || empty($last) || empty($email) || empty($uid) || empty($Phone) || empty($DOB_date) || empty($DOB_month) || empty($DOB_year) || empty($Address) || empty($pwd) || empty($Cpwd)) {
		header("Location: ../Register.php?signup=empty");
		exit();
	} else {
		//Check if input characters are valid
		if (!preg_match("/^[a-zA-Z]*$/", $first) || !preg_match("/^[a-zA-Z]*$/", $last) || !preg_match("/^[0-9\ ]*$/", $Phone) || !preg_match("/^[0-9]*$/", $DOB_date) || !preg_match("/^[0-9]*$/", $DOB_month) || !preg_match("/^[0-9]*$/", $DOB_year)) {

			 print_r($_POST);
			//header("Location: ../Register.php?signup=invalid");
			exit();
		} else {
			//Check if email is valid
			if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
				header("Location: ../Register.php?signup=email");
				exit();
			} else {
				$sql = "SELECT * FROM users WHERE Username='$uid'";
				$result = mysqli_query($conn, $sql);
				$resultCheck = mysqli_num_rows($result);

				if ($resultCheck > 0) {
					header("Location: ../Register.php?signup=usertaken");
					exit();

					$DOB_date_length = strlen($DOB_date);
					$DOB_month_length = strlen($DOB_month);
					$DOB_year_length = strlen($DOB_year);
				} else if ($DOB_date_length == 2 && $DOB_month_length == 2 && $DOB_year_length == 4) {
header("Location: ../Register.php?signup=Dob");
exit();
				} else if ($Cpwd == $pwd){
					//Hashing the password
					$hashedPwd = password_hash($pwd, PASSWORD_DEFAULT);

					$DOB = $DOB_date . "/" . $DOB_month . "/" . $DOB_year;
					//Insert the user into the database
					$sql = "INSERT INTO users (First, Last, Email, Username, password, DOB, Phone, Address) VALUES ('$first', '$last', '$email', '$uid', '$hashedPwd', '$DOB', '$Phone', '$Address');";
					mysqli_query($conn, $sql);

					header("Location: ../Login.php?signup=success");
					exit();
				} else {
					header("Location: ../Register.php?signup=PwdNotConfirmed");
				}
			}
		}
	}

} else {
	header("Location: ../Register.php");
	exit();
}
