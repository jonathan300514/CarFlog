<?php
$LoopPost = 0;

$CurrentItem = array("Search", "Man", "Auto", "Paint", "Make", "Sport", "Estate", "Con", "Coupe", "Other",
"Hatchback", "Diesel", "Petrol", "Limit", "Range", "Lat", "Long");

$Input = ' ';


while (isset($CurrentItem[$LoopPost])) {
  echo 'It works';
$TempVal = $CurrentItem[$LoopPost];
  if ($_POST[$TempVal] != NULL) {
    $Blank = '<input type="hidden" id="'.$CurrentItem[$LoopPost].'"
     name="'.$CurrentItem[$LoopPost].'" value="'. $_POST[$TempVal] . '">';
     $Input = $Input . $Blank;
  }

$LoopPost++;
}



?>
