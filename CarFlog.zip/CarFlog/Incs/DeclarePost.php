<?php
$searchedTerm = $_POST["Search"];
$Manual = $_POST["Man"];
$Auto = $_POST["Auto"];
$Paint = $_POST["Paint"];
$MakeCar = $_POST["Make"];
$ModelCar = $_POST["Model"];


$CarTypeSPORT = $_POST["Sport"];
$CarTypeEST = $_POST["Estate"];
$CarTypeCON = $_POST["Con"];
$CarTypeCO = $_POST["Coupe"];
$CarTypeOTHER = $_POST["Other"];
$CarTypeHAT = $_POST["Hatchback"];
$Diesel = $_POST["Diesel"];
$Petrol = $_POST["Petrol"];
$Electric = $_POST["Elec"];
$SemiAuto = $_POST["SemiAuto"];

$LimitNum = $_POST["Limit"];


$DistanceSet = $_POST["Range"];
$DistanceSet = round($DistanceSet);
$DistanceSet = (int)$DistanceSet;

?>
