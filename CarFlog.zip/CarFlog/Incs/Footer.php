<footer class="page-footer my-text">

  <div class="footer-copyright">
    <div class="container parent">
      <p class="Copyright"> © JSD - CarFlog (<?php echo date("Y") ?>) </p>
    </div>
  </div>
</footer>

<!--  Scripts-->
<script>
$(document).ready(function(){
  $('select').formSelect();
});
</script>

<script>

var x = document.getElementById("Long");
var y = document.getElementById("Lat");
function getLocation() {
  if (navigator.geolocation) {
      navigator.geolocation.watchPosition(showPosition);
  } else {
      x.innerHTML = "Geolocation is not supported by this browser.";}
  }

function showPosition(position) {
  x.value = position.coords.latitude;
  y.value = position.coords.longitude;
  ClickForm();
}

function ClickForm() {
document.getElementById("LocationSet").click();
}

document.addEventListener('DOMContentLoaded', function() {
   var elems = document.querySelectorAll('.fixed-action-btn');
   var instances = M.FloatingActionButton.init(elems, options);
 });
</script>

<script type="text/javascript">
$(document).ready(function(){
    $('.modal').modal();
  });
</script>

<script src="js/Modal.js"></script>
<script src="js/Dropdown.js"></script>
<script src="js/materialize.js"></script>
<script src="js/init.js"></script>

</body>
</html>
