<?php
//print_r($_POST);
//Your Database connection string
include 'Incs/Dbh.php';
session_start();
$UserID = $_SESSION['u_id'];

if (!isset($UserID)) {
  	header("Location: https://www.jd-sh.co.uk/CarFlog/index.php");
}

$CarID = $_GET['CarID'];

$sql = 'SELECT * FROM Search WHERE ItemID =' . $CarID;




$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
 // output data of each row
 while($row = mysqli_fetch_assoc($result)) {

  $VeichleID = $row["ItemID"];
   $Make = $row["Make"];
   $Model   = $row["Model"];
   $Gearbox = $row["Gearbox"];
   $PaintDb = $row["Paint"];
    $ID = $row["ItemID"];
    $FuelType = $row["FuelType"];
    $Age = $row["Age"];
    $Type = $row["Type"];
    $Price = $row["Price"];
    $Disc = $row["Disc"];
    $Doors = $row["Doors"];
    $EngSize = $row["EngineSize"];
   $LoopSet++;
 }
} else {
 echo " ";

}








$sql = 'SELECT * FROM CarPaint Where PaintID =' . $PaintDb;




$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
 // output data of each row
 while($row = mysqli_fetch_assoc($result)) {

  $PaintName = $row["Name"];
  $ColCode = $row["Code"];
   $LoopSet++;
 }
} else {
 echo " ";

}





$sql = 'SELECT * FROM CarImg Where ItemID =' . $CarID;




$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
 // output data of each row
 while($row = mysqli_fetch_assoc($result)) {

  $ImgPath = $row["ImgPath"];
  $ImageDisc = $row["ImageDisc"];
   $LoopSet++;
 }
} else {
 echo " ";

}

mysqli_close($conn);
?>


<?php

include 'Incs/HeadItems.php';
include 'Incs/Head.php';

?>
<main>

  <div class="section" id="index-banner">
    <div class="container CarImage">

<div class="row">
  <div class="col s6">
    <div class="center">
    <img src="<?php echo $ImgPath; ?>" class="responsive-img materialboxed hoverable" alt="<?php echo $Make . ' '.$Model?>-Image">

    <!-- z-depth-5-->

      <div class="Paint" style="margin-top: 10px; background-color: <?php echo $ColCode;?>"></div>
</div>
  </div>
<div class="col s6">
<?php
echo
'<h1 style="margin-top: 0px;">' . $Make . ' '. $Model . '</h1>
Gearbox: ' . $Gearbox . '<br>' .
'Colour: ' . $PaintName . '<br>' .
'Fuel: ' . $FuelType . '<br>' .
'Age: ' . $Age . ' Years <br>' .
'Car Type: ' . $Type . '<br>' .
'Price: £' . $Price . '<br>' .
'Description: ' . $Disc . '<br>' .
'Number of doors: ' . $Doors . '<br>' .
'EngineSize: ' . $EngSize . 'Ltr <br>' .
'Img Description: ' . $ImageDisc;




 include 'Incs/Modal.php';

 ?>
 </div><!--End of row-->
</div>
 <div class="row">
   <div class="right">
<a class="btn modal-trigger" href="#modalMail">Contact Seller</a>
</div>
</div><!--End col-->

    </div>
  </div>

</main>




<script>

$(document).ready(function(){
$('#modalMail').modal();
});

<?php

if ($_GET["Mes"] == 'Sent') {

echo 'alert("Message successfully sent")';

}
?>


function submitEmail() {
     $("#EmailForm").submit();
}


function validateForm() {
    var x = document.forms["EmailForm"]["Name"].value;
    if (x == "") {
        $("#ErrorName").html('A Name must be entered');
        return false;

    }
    var y = document.forms["EmailForm"]["Email"].value;
    if (y == "") {
      $("#ErrorEmail").html('An Email must be provided');
        return false;

    }
    var z = document.forms["EmailForm"]["Content"].value;
    if (z == "") {
      $("#ErrorContent").html('You havent entered a message');
        return false;

    }

    var emailaddress = document.forms["EmailForm"]["Email"].value;

    if( !validateEmail(emailaddress)) {
      $("#ErrorEmail").html('Your email is invalid');
      return false;
    }
}


function validateEmail($email) {
 var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
 return emailReg.test( $email );
}



</script>

<?php $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
?>

<!-- Modal Structure -->
<div id="modalMail" class="modal">
<div class="modal-content">
 <h4>Contact us</h4>
 <form action="Incs/Email.php" id="EmailForm" onsubmit="return validateForm()" method="post">
Name: <p id="ErrorName"></p> <input type="text" name="Name" placeholder="Enter your Fullname"><br>
Email: <p id="ErrorEmail"></p><input type="text" name="Email" placeholder="Enter your Email Address"><br>
Message: <p id="ErrorContent"></p> <textarea name="Content" rows="10" cols="30" placeholder="Add your message"></textarea><br>
<input type="hidden" name="URL" value="<?php echo $actual_link; ?>">
<input type="hidden" name="CarID" value="<?php echo $VeichleID; ?>">
</form>
</div>
<div class="modal-footer">
 <a href="#!" class="modal-close waves-effect waves-red btn-flat">Close</a>
 <a href="#!" class="waves-effect waves-green btn-flat" onClick='submitEmail()'>Send</a>
</div>
</div>

<script>  $(document).ready(function(){
    $('.materialboxed').materialbox();
  });</script>

<?php
include 'Incs/Footer.php';
 ?>
