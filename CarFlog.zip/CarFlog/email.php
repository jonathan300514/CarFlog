<?php

include 'Incs/Dbh.php';

// Multiple recipients

if (isset($_GET["Email"])) {
$to = $_GET["Email"];
$URL = 'Account.php';
} else {
$to = $_POST["Email"];
$URL = 'forgot.php';
}



function generateRandomString($length = 12) {
    return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
    ceil($length/strlen($x)) )),1,$length);
}



$URLTwo = 'index.php';




$Code = generateRandomString();
$Time = time();
$link = 'https://www.jd-sh.co.uk/CarFlog/reset.php?UserCode=' . $Code . '&Adr=' . $to;




$sql4 = "SELECT * FROM users WHERE email = '$to'";

$result4 = mysqli_query($conn, $sql4);
if (mysqli_num_rows($result4) > 0) {


$sql2 = "SELECT * FROM SRecover WHERE Email = '$to'";
//SELECT * FROM conntent WHERE PageID = 1 && ItemRank = 0 || ItemRank = 3 ORDER BY PgOrder ASC  $UserRank

$result2 = mysqli_query($conn, $sql2);
if (mysqli_num_rows($result2) > 0) {
 // output data of each row
//OverWrite the previous request.
$sql3 = "UPDATE SRecover SET RequestTime = '$Time', SecretCode = '$Code' WHERE Email = '$to'";


$result3 = mysqli_query($conn, $sql3);



} else {

  //INSERT INTO `jonathan3005_2`.`SRecover` (`PassResetID`, `RequestTime`, `SecretCode`, `Email`) VALUES (NULL, '', '', '');


  $sql1 = "INSERT INTO `jonathan3005_4`.`SRecover` (`PassResetID`, `RequestTime`, `SecretCode`, `Email`) VALUES (NULL, '$Time', '$Code', '$to')";


  $result1 = mysqli_query($conn, $sql1);

}



  mysqli_close($conn);


// Subject
$subject = "Your password reset for your CarFlog account";

// Message
$message = '<html>
<head>
  <title>Your password reset for your CarFlog account</title>

  <style>

  .button {
      background-color: #4CAF50; /* Green */
      border: none;
      color: white;
      padding: 16px 32px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 16px;
      margin: 4px 2px;
      -webkit-transition-duration: 0.4s; /* Safari */
      transition-duration: 0.4s;
      cursor: pointer;
  }

  .button3 {
      background-color: white;
      color: black;
      border: 2px solid #f44336;
  }

  .button3:hover {
      background-color: #f44336;
      color: white;
  }

  </style>

</head>
<body>
  <p>Please use the below link to proceed to reset your password.</p>



<a href="'.$link.'" class="button button3"><h4 style="color:#333333;">Reset password</h4></a>




</body>
</html>';

// To send HTML mail, the conntent-type header must be set
$headers[] = 'MIME-Version: 1.0';

$headers[] = "Content-Type: text/html; charset=UTF-8";

// Additional headers
$headers[] = 'From: CarFlog <CarFlog@mail.com>';


// Mail it
mail($to, $subject, $message, implode("\r\n", $headers));

header('Location: '.$URL.'?Output=1');
//The message has been sent and you will have 12hrs to react.

} else {
header('Location: '.$URL.'?Output=0');
//This email isnt in our records. Try again.
}


?>
