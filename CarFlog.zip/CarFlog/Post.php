<?php

//print_r($_POST);
//Your Database connection string
include 'Incs/Dbh.php';
session_start();
$UserID = $_SESSION['u_id'];

if (!isset($UserID)) { //inital check to check user is set
  	header("Location: https://www.jd-sh.co.uk/CarFlog/index.php");
}

mysqli_close($conn);
?>


<?php

include 'Incs/HeadItems.php';
include 'Incs/Head.php';

?>
<main>

  <div class="section" id="index-banner">
    <div class="container">
<h1 class="center">Post your car</h1>
<label>Use GPS</label><br><br>
<button type="button" onclick="getLocation()"><i class="material-icons">gps_fixed</i></button>
    <form action="CarCreate.inc.php" method="post" enctype="multipart/form-data">
      <input type="hidden"  name="Long" id="Long" value="<?php echo  $_GET["Long"]; //Fills out form?>">
      <input type="hidden"  name="Lat"  id="Lat"  value="<?php echo  $_GET["Lat"];  ?>">

      Select image to upload:
    <input type="file" name="fileToUpload" id="fileToUpload">
<div class="row">
      <div class="col s6">
     Brand:<br>
      <input type="text" name="Brand" value="<?php echo $Brand; ?>">
</div>
<div class="col s6">
     Model:<br>
      <input type="text" name="Model" value="<?php echo $Model; ?>">
      </div>
      </div>
      <div class="row">
<div class="col s6">
      Gearbox:<br>
       <input type="text" name="Gearbox" value="<?php echo $Gearbox; ?>">
       </div>
<div class="col s6">
       Description:<br>
        <input type="text" name="Disc" value="<?php echo $Disc; ?>">
      </div>
      </div>
      <div class="row">
<div class="col s6">
        Miles:<br>
         <input type="text" name="Miles" value="<?php echo $Miles; ?>">
         </div>
<div class="col s6">
     Age:<br>
      <input type="text" name="Age" value="<?php echo $Age; ?>">
    </div>
    </div>
    <div class="row">
<div class="col s6">
      Fuel:<br>
       <input type="text" name="Fuel" value="<?php echo $Fuel; ?>">
       </div>
<div class="col s6">
     No of Doors:<br>
      <input type="text" name="No" value="<?php echo $No; ?>">
    </div>
    </div>
    <div class="row">
<div class="col s6">
      Type:<br>
       <input type="text" name="Type" value="<?php echo $Type; ?>">
       </div>
<div class="col s6">
       Paint:<br>
        <input type="text" name="Paint" value="<?php echo $Paint; ?>">
      </div>
      </div>
      <div class="row">
<div class="col s6">
        Engine Size:<br>
         <input type="text" name="Eng" value="<?php echo $Eng; ?>">
         </div>
<div class="col s6">
         Price:<br>
          <input type="text" name="Price" value="<?php echo $Price; ?>">
        </div>
        </div>

      <br>
     <div class="center">
       <input type="submit" name="submit" value="Create" class="btn">
     </div>
    </form>


</div>



</div>

</main>
<script>  $(document).ready(function(){
    $('.materialboxed').materialbox();
  });</script>

<?php

 include 'Incs/Modal.php';


include 'Incs/Footer.php';
 ?>
