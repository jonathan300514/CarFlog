<?php

//print_r($_POST);
//Your Database connection string
include 'Incs/Dbh.php';
session_start();
$UserID = $_SESSION['u_id'];

mysqli_close($conn);
?>


<?php

include 'Incs/HeadItems.php';
include 'Incs/Head.php';

?>
<main>


    <div id="myDiv" class="animate-bottom">


      <h5 style="color: #213368; text-transform: uppercase;">Please input your new password.</h5>
<script>
function checkPasswordMatch() { //This is the function checks the passwords match
    var password = $("#txtNewPassword").val();
    var connfirmPassword = $("#txtconnfirmPassword").val();
//Checks password vs password check
    if (password != connfirmPassword)
        $("#divCheckPasswordMatch").html("Passwords do not match!");
    else
        $("#divCheckPasswordMatch").html("Passwords match.");
}

$(document).ready(function () {
   $("#txtNewPassword, #txtconnfirmPassword").keyup(checkPasswordMatch);
});

 </script>




      <div class="conntainer">
        <div class="z-depth-1 row" style="display: inline-block; padding: 32px 48px 0px 48px; border: 2px solid #00A8E1; background-color: #213368;">
<?php

$adr = $_GET['Adr'];
$Cde = $_GET['UserCode'];

 $fullLink = 'Incs/NewPass.inc.php?UserCode='.$Cde.'&Adr='.$adr; ?>

          <form class="col s12" action="<?php echo $fullLink ?>" method="POST">

            <div class='row'>
              <div class='col s12'>
              </div>
            </div>


            <div class='row'>
              <label for='Pass' style="color: #fff; font-size: 14px;">Enter your new password.</label>
              <div class='input-field col s12'>
                <input pattern=".{6,32}"  class='validate' type='text' name='Pass' id="txtNewPassword" style="text-align: center; color: #fff;" id='Pass'/>

              </div>
            </div>

            <div class='row'>
              <label for='Passconnfirm' style="color: #fff; font-size: 14px;">confirm your new password.</label>
              <div class='input-field col s12'>

                <input pattern=".{6,32}" class='validate' type='text' name='Passconnfirm' id="txtconnfirmPassword" onChange="checkPasswordMatch();" style="text-align: center; color: #fff;" id='Passconnfirm'/>

                <input type="hidden" name="Email" id="hiddenField" value="<?php echo $_GET['Adr'] ?>" />



              </div>
            </div>
            <div class='row'>
              <button type='submit' name='submit' class='col s12 btn btn-large waves-effect indigo hvr-grow'>Reset password</button>
            </div>

          </form>


          </div>

</div>




        </div>

</main>
<script>  $(document).ready(function(){
    $('.materialboxed').materialbox();
  });</script>

<?php
include 'Incs/Footer.php';
 ?>
