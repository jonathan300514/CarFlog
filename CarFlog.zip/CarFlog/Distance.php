<?php
//print_r($_POST);
include 'Incs/Dbh.php';

include 'Incs/Distance.calc.php';


$val = 0;
$DistanceSet = $_POST["Range"];

$DistanceSet = (int)$DistanceSet;
$Dist = 20;


$LoopsetDist = 0;

$SqlDist = "SELECT * FROM Search";

$result = mysqli_query($conn, $SqlDist);
if (mysqli_num_rows($result) > 0) {
 // output data of each row
 while($row = mysqli_fetch_assoc($result)) {

  $Make[$LoopsetDist] = $row["Make"];
  $Location[$LoopsetDist] = $row["Location"];
  $LongDB[$LoopsetDist] = $row["LocationLong"];
  $LatDB[$LoopsetDist] = $row["LocationLat"];


  $DistCalc = distance($_POST["Lat"], $_POST["Long"], $LatDB[$LoopsetDist], $LongDB[$LoopsetDist] , "M") . " Miles<br>";

  if ($DistCalc < $DistanceSet) {
    echo $Make[$LoopsetDist] . '<br>';
    echo $Location[$LoopsetDist] . '<br>';
    Echo 'You are approximatly ' . floor($DistCalc) . ' Miles away from this vehicle.' . '<br><br>';
    echo '<br>';
  }



   $LoopsetDist++;
 }
} else {
 echo " ";

}


?>

 <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">


<p>Click the button to get your coordinates.</p>

<button onclick="getLocation()">Use your location<i class="material-icons">location_searching</i></button>

<p id="LongOutput"></p>
<p id="LatOutput"></p>





    <form action="Distance.php" method="post">

  <input type="hidden" id="Long" name="Long" value="<?php echo  $_POST["Long"]; ?>">
  <input type="hidden" id="Lat" name="Lat" value="<?php echo $_POST["Lat"]; ?>">
  <input type="text" id="Range" name="Range" value="<?php echo $DistanceSet; ?>">
  <input type="submit" id="LocationSet" value="Change My Range">

    </form>



<script>

var x = document.getElementById("Long");
var y = document.getElementById("Lat");
function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.watchPosition(showPosition);
    } else {
        x.innerHTML = "Geolocation is not supported by this browser.";}
    }


function showPosition(position) {
    x.value = position.coords.latitude;
    y.value = position.coords.longitude;
    ClickForm();
}


function ClickForm() {
  document.getElementById("LocationSet").click();
}





</script>




</body>
</html>
