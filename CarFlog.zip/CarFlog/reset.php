<?php
//declaring variables
include 'Incs/Dbh.php';
$URL = 'https://www.jd-sh.co.uk/CarFlog/forgot.php';

//Checks the details are avalible
if ((isset($_GET["UserCode"])) && (isset($_GET["Adr"]))) {
$Chuck = ' ';
} else {
  header('Location: '.$URL);
}

/*Db Logic*/

$Time = time();

$AddVal = 60 * 60 * 12;
$SctCode = $_GET["UserCode"];
$EmailAdr = $_GET["Adr"];
$DbTime = $Time - $AddVal;

//Sets the reset request variables
 $DbTime = (int)$DbTime;



//1hr 1535769860
//12hrs 1535809628




//SELECT * FROM `SRecover` where RequestTime < 1535769860 && Email = 'jonathandartnell3005@gmail.com' && SecretCode = '111222333444a'



$sql1 = "SELECT * FROM SRecover where RequestTime > $DbTime && Email = '$EmailAdr' && SecretCode = '$SctCode'";
//Selects the reset from the db


$result1 = mysqli_query($conn, $sql1);
if (mysqli_num_rows($result1) > 0) {
 // output data of each row

 while($row = mysqli_fetch_assoc($result1)) {


   $ID = $row["Email"];
//Grabs user email
 }
} else {
 echo " ";

}

mysqli_close($conn);


if (isset($ID)) {
include 'NewPass.php';   //Valid request redirect
} else {
  header('Location: '.$URL);
}




 ?>
