$(document).ready(function(){
  $(".dropdown-trigger").dropdown();
});
