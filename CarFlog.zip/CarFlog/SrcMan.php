<?php

//print_r($_POST);
//Your Database connection string
include 'Incs/Dbh.php';

//setup user on page
session_start();
$UserID = $_SESSION['u_id'];

/*Starts the loop incrementaion*/
$SearchLoop = 0;

/*SQL for the Saved search*/

$sql = "SELECT * FROM Searches where UserID = " . $UserID . " ORDER BY Used DESC";

/*Start of value setting from SQL ressuts*/

  $result = mysqli_query($conn, $sql);



if (mysqli_num_rows($result) > 0) {
 // output data of each row
 while($row = mysqli_fetch_assoc($result)) {

  $SHID[$SearchLoop] = $row["SearchID"];
  $SHName[$SearchLoop] = $row["Name"];

  $QueryItems = explode("¬", $SHQuery[$SearchLoop]);


/*Will convert table contents to POST data for use with the rest of the Search System*/
$SearchLoop++;
}
}


mysqli_close($conn);

//Declare all header and nav
include 'Incs/HeadItems.php';
include 'Incs/Head.php';

 include 'Incs/Modal.php';
//search modal
?>
<main>

  <div class="section" id="index-banner">
    <div class="container">


      <table class="centered responsive-table striped">
              <thead>
                <tr>
                    <th>Name</th>
                    <th>Delete</th>
                </tr>
              </thead>

              <tbody>



<?php

$LoopHead = 0; //open loop for search form for managing queries
while (isset($SHID[$LoopHead])) {

   echo '<tr>
     <td>
'. $SHName[$LoopHead] .'
</td>

<td>

<form action="https://www.jd-sh.co.uk/CarFlog/Incs/DelQuery.php" method="post" id="Del'.$SHID[$LoopHead].'" style="height: 1%;">
<input type="hidden" id="Del" name="Del" value="'.$SHID[$LoopHead].'">

<a href="#!" onclick="document.getElementById(\'Del'.$SHID[$LoopHead].'\').submit()">  <i class="material-icons">backspace</i> </a>

</form>

</td>

</tr>
';

$LoopHead++;

//Incs the loop values
}

 ?>

</tbody>
</table>

    </div>
  </div>

</main>



<?php
include 'Incs/Footer.php';
//Includes the footer code
 ?>
