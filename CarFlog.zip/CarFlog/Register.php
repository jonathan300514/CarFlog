<?php
session_start();

if(isset($_SESSION['usr_id'])) {
	header("Location: index.php");
}
//Includes all neccisary files for the page
require 'Incs/Dbh.php';
include 'Incs/HeadItems.php';
include 'Incs/Head.php';
?>




  <main>
	<link href="css/LogStyle.css" type="text/css" rel="stylesheet" media="all"/>



	<div class="container log">
		<div class="row">
			<div class="col-md-4 col-md-offset-4 well">
			<h1 class="TextAlign black-text">Register</h1>
			<form action="Incs/Signup.inc.php" method="post" name="signupform">
				<fieldset>

					<div class="form-group">
						<label for="First" class="black-text">First Name</label>
						<input id="First" type="text" name="First" placeholder="Enter Full Name" required value="<?php if($error) echo $First; ?>" class="form-control black-text" />
						<span class="text-danger"><?php //echos all odbc_errormsg
						 if (isset($name_error)) echo $name_error; ?></span>
					</div>

					<div class="form-group">
						<label for="Last" class="black-text">Last Name</label>
						<input id="Last" type="text"  name="Last" placeholder="Enter Last Name" required value="<?php if($error) echo $Last; ?>" class="form-control black-text" />
						<span class="text-danger"><?php if (isset($name_error)) echo $name_error; ?></span>
					</div>

					<div class="form-group">
						<label for="Email" class="black-text">Email</label>
						<input id="Email" type="text" name="Email" placeholder="Email" required value="<?php if($error) echo $Email; ?>" class="form-control black-text" />
						<span class="text-danger"><?php if (isset($email_error)) echo $email_error; ?></span>
					</div>

					<div class="form-group">
						<label for="Username" class="black-text">Username</label>
						<input id="Username" type="text" name="Username" placeholder="Username" required value="<?php if($error) echo $Username; ?>" class="form-control black-text" />
						<span class="text-danger"><?php if (isset($email_error)) echo $email_error; ?></span>
					</div>


					<div class="form-group">
						<label for="Phone_Number" class="black-text">Phone Number</label>
						<input id="Phone_Number" type="text" name="Phone_Number" placeholder="Phone_Number" required value="<?php if($error) echo $Phone_Number; ?>" class="form-control black-text" />
						<span class="text-danger"><?php if (isset($Phone_Number_error)) echo $Phone_Number_error; ?></span>
					</div>


					<div class="form-group">
						<label for="DOB_date" class="black-text">DOB_date</label>
						<input id="DOB_date" type="text" name="DOB_date" placeholder="DOB_date" required value="<?php if($error) echo $DOB_date; ?>" class="form-control black-text" />
						<span class="text-danger"><?php if (isset($DOB_date_error)) echo $DOB_date_error; ?></span>
					</div>

					<div class="form-group">
						<label for="DOB_month" class="black-text">DOB_month</label>
						<input id="DOB_month" type="text" name="DOB_month" placeholder="DOB_month" required value="<?php if($error) echo $DOB_month; ?>" class="form-control black-text" />
						<span class="text-danger"><?php if (isset($DOB_month_error)) echo $DOB_month_error; ?></span>
					</div>

					<div class="form-group">
						<label for="DOB_year" class="black-text">DOB_year</label>
						<input id="DOB_year" type="text" name="DOB_year" placeholder="DOB_year" required value="<?php if($error) echo $DOB_year; ?>" class="form-control black-text" />
						<span class="text-danger"><?php if (isset($DOB_year_error)) echo $DOB_year_error; ?></span>
					</div>

					<div class="form-group">
						<label for="Address" class="black-text">Address</label>
						<input id="Address" type="text" name="Address" placeholder="Address" required value="<?php if($error) echo $Address; ?>" class="form-control black-text" />
						<span class="text-danger"><?php if (isset($Address_error)) echo $Address_error; ?></span>
					</div>

					<div class="form-group">
						<label for="Password" class="black-text">Password</label>
						<input id="Password" type="password" name="Password" placeholder="Password" required class="form-control black-text" />
						<span class="text-danger"><?php if (isset($password_error)) echo $password_error; ?></span>
					</div>

					<div class="form-group">
						<label for="CPassword" class="black-text">Confirm Password</label>
						<input id="CPassword" type="password" name="CPassword" placeholder="Confirm Password" required class="form-control black-text" />
						<span class="text-danger"><?php if (isset($cpassword_error)) echo $cpassword_error; ?></span>
					</div>


					<div class="form-group TextAlign">
						<input type="submit" name="submit" value="submit" class="btn" />
					</div>
				</fieldset>
			</form>
			<span class="text-success"><?php if (isset($successmsg)) { echo $successmsg; } ?></span>
			<span class="text-danger"><?php if (isset($errormsg)) { echo $errormsg; } ?></span>
		</div>
	</div>
	<div class="row">
		<div class="col-md-4 col-md-offset-4 text-center black-text">
		Already Registered? <a href="Login.php" class="black-text">Login Here</a>
		</div>
	</div>
</div>


</main>

<?php
include 'Incs/Footer.php';
 ?>
