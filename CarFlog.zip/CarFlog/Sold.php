<?php

//print_r($_POST);
//Your Database connection string
include 'Incs/Dbh.php';
session_start();

//Declared variables
$UserID = $_SESSION['u_id'];
$URL = 'https://www.jd-sh.co.uk/CarFlog/Account.php';

$CarID = $_GET['CarID'];
$Mod   = $_GET['Mod'];
if (($Mod == 1) && (isset($CarID))) {
  $sql = "UPDATE Search SET Sold='1' WHERE ItemID = '$CarID'";
  //This is an sql statement/query to update the sold status
  //echo $sql;
  $result = mysqli_query($conn, $sql);

    header('Location: '. $URL .'?Change=sucess');
} else { //these headers redirect the Url to show the status of the sql
    header('Location: '. $URL .'?Change=SaleInv');
}

?>
