<?php

//print_r($_POST);
//Your Database connection string
include 'Incs/Dbh.php';
session_start();
$UserID = $_SESSION['u_id'];

mysqli_close($conn);
?>


<?php

include 'Incs/HeadItems.php';
include 'Incs/Head.php';

?>


    <?php

  if (isset($_GET["Output"])) {
    if ($_GET["Output"] == "1") {
      echo "An email has been sent to your email address, please allow upto an hour. You will have 24hrs to respond and change your password";
    } else {
      Echo "Your email was not found, This could be due to your account not exisiting or a typo. Please try again.";
    }

  }
?>

  <main>
    <div class="section" id="index-banner">



    <div id="myDiv" class="animate-bottom">


      <h5 style="color: #213368; text-transform: uppercase;">Account Recovery</h5>

      <script>



      function submitEmail() {
           $("#EmailForm").submit();
      }


      function validateForm() {

          var y = document.forms["EmailForm"]["Email"].value;
          if (y == "") {
            $("#ErrorEmail").html('An Email must be provided');
              return false;

          }
          var emailaddress = document.forms["EmailForm"]["Email"].value;

          if( !validateEmail(emailaddress)) {
            $("#ErrorEmail").html('Your email is invalid');
            return false;
          }
      }


      function validateEmail($email) {
       var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
       return emailReg.test( $email );
      }
      </script>





      <div class="container">
        <div class="z-depth-1 row" style="display: inline-block; padding: 32px 48px 0px 48px; border: 2px solid #00A8E1; background-color: #213368;">

            <form class="col s12" action="email.php" id="EmailForm" onsubmit="return validateForm()" method="post">

            <div class='row'>
              <div class='col s12'>
              </div>
            </div>

            <div class='row'>
              <label for='email' style="color: #fff; font-size: 14px;">Enter your email for recovery.</label>
              <div class='input-field col s12'>
                Email: <p id="ErrorEmail"></p><input class='validate' type='text' name='Email' style="text-align: center; color: #fff;" id='email'/>

              </div>
            </div>


              <div class='row'>
                <button type='submit' name='submit' class='col s12 btn btn-large waves-effect indigo hvr-grow'>Reset</button>
              </div>

          </form>

        </div>
      </div>
</div>




</div>

</main>
<script>  $(document).ready(function(){
    $('.materialboxed').materialbox();
  });</script>

<?php
include 'Incs/Footer.php';
 ?>
