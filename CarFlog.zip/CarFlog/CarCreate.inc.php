<?php

print_r($_POST);
//Your Database connection string
include 'Incs/Dbh.php';
session_start();
$UserID = $_SESSION['u_id'];
$URL = 'https://www.jd-sh.co.uk/CarFlog/Post.php';
$URL2 = 'https://www.jd-sh.co.uk/CarFlog/Account.php';


$Brand = $_POST['Brand'];
$Model = $_POST['Model'];
$Gearbox = $_POST['Gearbox'];
$Disc = $_POST['Disc'];
$Miles = $_POST['Miles'];
$Age = $_POST['Age'];
$No = $_POST['No'];
$Fuel = $_POST['Fuel'];
$Paint = $_POST['Paint'];
$Eng = $_POST['Eng'];
$Price = $_POST['Price'];
$Lat = $_POST['Lat'];
$Long = $_POST['Long'];
$Type = $_POST['Type'];


if (empty($Brand) || empty($Model) || empty($Gearbox) || empty($Disc) || empty($Miles) || empty($Age) || empty($No) || empty($Fuel) || empty($Paint) || empty($Eng) || empty($Price) || empty($Long)
|| empty($Lat) || empty($Type)) {
  header('Location: '. $URL .'?Change=empty');
  exit();
} else {
  //Check if input characters are valid
  if (!preg_match("/^[a-zA-Z]*$/", $Brand) || !preg_match("/^[a-zA-Z0-9\ ]*$/", $Model) || !preg_match("/^[a-zA-Z]*$/", $Gearbox) || !preg_match("/^[a-zA-Z0-9\ \.]*$/", $Disc) || !preg_match("/^[0-9]*$/", $Miles)
  || !preg_match("/^[0-9]*$/", $Age) || !preg_match("/^[0-9]*$/", $No) || !preg_match("/^[a-zA-Z]*$/", $Fuel) || !preg_match("/^[0-9]*$/", $Paint) || !preg_match("/^[0-9\.]*$/", $Eng)
  || !preg_match("/^[0-9]*$/", $Price) || !preg_match("/^[a-zA-Z]*$/", $Type)) {
    header('Location: '. $URL .'?Change=invalid');
    exit();
  } else {

    $Details = 1;
  }
}



$target_dir = "CarImg/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        $uploadOk = 1;
    } else {
        header('Location: '. $URL .'?Car=IMGINC');
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    header('Location: '. $URL .'?Car=exists');
    $uploadOk = 0;
}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 5000000) {
   header('Location: '. $URL .'?Car=IMGLARGE');
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    header('Location: '. $URL .'?Car=FileFormat');
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
   header('Location: '. $URL .'?Car=FailedIMG');
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        $IMG = 1;
    } else {
        header('Location: '. $URL .'?Car=error');
    }
}

if ($IMG == 1 && $Details == 1) {


  $sql = "SELECT * FROM Search ORDER BY ItemID DESC LIMIT 1";

  //echo $sql;
  $result = mysqli_query($conn, $sql);

  if (mysqli_num_rows($result) > 0) {
   // output data of each row
   while($row = mysqli_fetch_assoc($result)) {

  $ItemID = $row["ItemID"];

   }
  }




$ItemID++;


$Disc = explode(".", $_FILES["fileToUpload"]["name"]);
$DISC = $Disc[0];

$sql = "INSERT INTO CarImg VALUES (NULL, '$ItemID', '$target_file', '$DISC')";


//echo $sql;
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
 // output data of each row
 while($row = mysqli_fetch_assoc($result)) {

$ItemID = $row["ItemID"];

 }
}

$sql = "INSERT INTO Search VALUES (NULL, '$UserID',
'$Brand',
'$Model',
'$Gearbox',
'$Disc',
'$Miles',
'$Age',
'$Fuel',
'$No',
'$Type',
'$Paint',
'$Eng',
'$Price',
'$Lat',
'$Long', 0 , 0)";



//echo $sql;
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
 // output data of each row
 while($row = mysqli_fetch_assoc($result)) {

$ItemID = $row["ItemID"];

 }
}


header('Location: '. $URL2 .'?Car=success');


}






?>
